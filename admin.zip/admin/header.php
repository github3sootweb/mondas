<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta https-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>مدیریت</title>
    <link rel="icon" type="image/x-icon" href="http://mondas.ir/admin/assets/img/favicon.ico"/>
    <link href="http://mondas.ir/admin/assets/css/loader.css" rel="stylesheet" type="text/css"/>
    <script src="http://mondas.ir/admin/assets/js/loader.js"></script>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="httpss://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
    <link href="http://mondas.ir/admin/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="http://mondas.ir/admin/assets/css/plugins.css" rel="stylesheet" type="text/css"/>
    <link href="http://mondas.ir/admin/assets/css/structure.css" rel="stylesheet" type="text/css" class="structure"/>
    <!-- END GLOBAL MANDATORY STYLES -->
    <link rel="stylesheet" type="text/css" href="http://mondas.ir/admin/plugins/table/datatable/datatables.css">
    <link rel="stylesheet" type="text/css" href="http://mondas.ir/admin/plugins/table/datatable/custom_dt_html5.css">
    <link rel="stylesheet" type="text/css" href="http://mondas.ir/admin/plugins/table/datatable/dt-global_style.css">
    <link href="http://mondas.ir/admin/assets/css/scrollspyNav.css" rel="stylesheet" type="text/css"/>
    <link href="http://mondas.ir/admin/assets/css/authentication/form-2.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="http://mondas.ir/admin/assets/css/forms/theme-checkbox-radio.css">
    <link rel="stylesheet" type="text/css" href="http://mondas.ir/admin/assets/css/forms/switches.css">
    <link href="http://mondas.ir/admin/assets/css/scrollspyNav.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="http://mondas.ir/admin/plugins/select2/select2.min.css">
</head>