<?php

$url = "http://mondas.ir:4000";

function signIn()
{
    if (isset($_POST['signIn'])) {
        global $url;
        $userName = $_POST['username'];
        $password = $_POST['password'];
    
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "$url/users/Login",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('username' => "$userName",'password' => "$password"),
        ));
        
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == "true") {
            setcookie('id', $info->id, time() + 1 * 24 * 60 * 60);
            // echo "<script type='text/javascript'> document.cookie = 'id=$show->id';</script>";
            echo "<script type='text/javascript'> document.location = 'dashboard'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'managementLogin?enter=false'; </script>";
        }
    }
}


function getDataById($value, $item)
{
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/$item",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data[0];
    } else {

    }
}

function getCategories(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetCategories",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addCategories(){
    if(isset($_POST['add'])){
        global $url;
        $title = $_POST['title'];
        $description = $_POST['description'];
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/categories/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/categories/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'addCategories?add=false'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'addCategories?add=error'; </script>";
            }
        }
        if (!empty($_POST['gold'])) {
            $gold = "True";
        } else {
            $gold = "False";
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddCategories",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('title' => "$title",'description' => "$description",'image'=> "$image" , 'gold' => "$gold"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'categories?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addCategories?add=false'; </script>";
        }
    }
}

function editCategories($value){
    if(isset($_POST['edit'])){
        global $url;
        $title = $_POST['title'];
        $description = $_POST['description'];
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/categories/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/categories/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'editCategories?change=false&edit=$value'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'editCategories?change=error&edit=$value'; </script>";
            }
        }
        if (!empty($_POST['gold'])) {
            $gold = "True";
        } else {
            $gold = "False";
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/EditCategories",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('id'=>"$value" , 'title' => "$title" , 'description' => "$description" , 'image'=> "$image"  , 'gold' => "$gold"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'categories?change=true&edit=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editCategories?change=false&edit=$value'; </script>";
        }
    }
}

function deleteCategory($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeleteCategories",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'categories?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'categories?delete=false'; </script>";
    }
}

function getCollactions(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetColactions",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addCollaction(){
    if(isset($_POST['add'])){
        global $url;
        $title = $_POST['title'];
        $description = $_POST['description'];
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/collections/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/collections/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'addCollaction?add=false'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'addCollaction?add=error'; </script>";
            }
        }
        if (!empty($_POST['gold'])) {
            $gold = "True";
        } else {
            $gold = "False";
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddColactions",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('title' => "$title",'description' => "$description",'image'=> "$image" , 'gold' => "$gold"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'collaction?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addCollaction?add=false'; </script>";
        }
    }
}

function editCollaction($value){
    if(isset($_POST['edit'])){
        global $url;
        $title = $_POST['title'];
        $description = $_POST['description'];
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/collections/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/collections/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'editCollaction?change=false&edit=$value'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'editCollaction?change=error&edit=$value'; </script>";
            }
        }
        if (!empty($_POST['gold'])) {
            $gold = "True";
        } else {
            $gold = "False";
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/EditColactions",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('id' => "$value" , 'title' => "$title",'description' => "$description",'image'=> "$image" , 'gold' => "$gold"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'collaction?change=true&edit=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editCollaction?change=false&edit=$value'; </script>";
        }
    }
}

function deleteCollaction($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeleteColactions",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'collaction?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'collaction?delete=false'; </script>";
    }
}

function getProduct(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProducts",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        $all = [$info->data , $info->gold_price , $info->silver_price];
        return $all;
    } else {

    }
}

function addProduct(){
    if(isset($_POST['add'])){
        global $url;
        $categoryId = $_POST['categoryId'];
        $name = $_POST['name'];
        $count = $_POST['count'];
        $is_off = $_POST['is_off'];
        $offPercent = $_POST['offPercent'];
        $weight = $_POST['weight'];
        $gold_carat = $_POST['gold_carat'];
        $gens = $_POST['gens'];
        $model = $_POST['model'];
        $color = $_POST['color'];
        $is_gold = $_POST['is_gold'];
        $description = $_POST['description'];
        $collactionId = $_POST['collactionId'];

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddProduct",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('colaction' => "$collactionId" , 'category' => "$categoryId",'name' => "$name",'description' => "$description",'count' => "$count",'is_off' => "$is_off",'off_percent' => "$offPercent",'weight' => "$weight",'is_gold' => "$is_gold",'gold_carat' => "$gold_carat",'gender' => "$gens",'model' => "$model",'color' => "$color" , 'seen' => '0'),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'product?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addProduct?add=false'; </script>";
        }
    }
}

function editProduct($value){
    if(isset($_POST['edit'])){
        global $url;
        $categoryId = $_POST['categoryId'];
        $name = $_POST['name'];
        $count = $_POST['count'];
        $is_off = $_POST['is_off'];
        $offPercent = $_POST['offPercent'];
        $weight = $_POST['weight'];
        $gold_carat = $_POST['gold_carat'];
        $gens = $_POST['gens'];
        $model = $_POST['model'];
        $color = $_POST['color'];
        $is_gold = $_POST['is_gold'];
        $description = $_POST['description'];
        $collactionId = $_POST['collactionId'];

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/EditProduct",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('id'=>"$value" , 'colaction' => "$collactionId" , 'category' => "$categoryId",'name' => "$name",'description' => "$description",'count' => "$count",'is_off' => "$is_off",'off_percent' => "$offPercent",'weight' => "$weight",'is_gold' => "$is_gold",'gold_carat' => "$gold_carat",'gender' => "$gens",'model' => "$model",'color' => "$color"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'product?change=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editProduct?edit=$value&change=false'; </script>";
        }
    }
}

function deleteProduct($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeleteProduct",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'product?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'product?delete=false'; </script>";
    }
}

function getProductImage($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProductImages",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('product' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addProductImage($value){
    if(isset($_POST['add'])){
        global $url;
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/productImage/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/productImage/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'addImages?add=false&image=$value'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'addImages?add=error&image=$value'; </script>";
            }
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddProductImage",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('product' => "$value" , 'image' => "$image"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'Images?add=true&image=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addImages?add=unable&image=$value'; </script>";
        }
    }
}

function editProductImage($value , $item){
    if(isset($_POST['edit'])){
        global $url;
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/productImage/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/productImage/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'editImage?edit=false&id=$item&image=$value'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'editImage?edit=error&id=$item&image=$value'; </script>";
            }
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/EditProductImage",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('id' => "$item" , 'product' => "$value" , 'image' => "$image"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'Images?edit=true&image=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editImage?edit=unable&id=$item&image=$value'; </script>";
        }
    }
}

function deleteProductImage($value , $item){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeleteProductImage",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'Images?delete=true&image=$item'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'Images?delete=false&image=$item'; </script>";
    }
}

function getProductPrice($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProductPrice",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('product' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addProductPrice($value){
    if(isset($_POST['add'])){
        global $url;
        $userId = $_POST['userId'];
        $price = $_POST['price'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddProductPrice",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('product' => "$value",'user' => "$userId",'price' => "$price"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'Price?add=true&price=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addPrice?add=false&price=$value'; </script>";
        }
    }
}

function editProductPrice($value , $item){
    if(isset($_POST['edit'])){
        global $url;
        $userId = $_POST['userId'];
        $price = $_POST['price'];
        $is_off = $_POST['is_off'];
        $off_percent = $_POST['off_percent'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/EditProductPrice",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('id' => "$item" , 'product' => "$value",'user' => "$userId",'price' => "$price",'is_off' => "$is_off",'off_percent' => "$off_percent"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'Price?edit=true&price=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editPrice?edit=false&id=$item&price=$value'; </script>";
        }
    }
}

function deleteProductPrice($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeleteProductPrice",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'Price?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'productPrice?delete=false'; </script>";
    }
}

function getLetMeKnow(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetLetMyKnow",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function deleteLetMeKnow($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeleteLetMyKnow",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'letMeKnow?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'letMeKnow?delete=false'; </script>";
    }
}

function getSliders(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/GetSliders",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addSliders(){
    if(isset($_POST['add'])){
        global $url;
        $title = $_POST['title'];
        $url = $_POST['url'];
        if (!empty($_POST['firstPage'])) {
            $first_page = "True";
        } else {
            $first_page = "False";
        }
        if (!empty($_POST['goldPage'])) {
            $gold_page = "True";
        } else {
            $gold_page = "False";
        }
        if (!empty($_POST['silverPage'])) {
            $silver_page = "True";
        } else {
            $silver_page = "False";
        }
        if (!empty($_POST['omdePage'])) {
            $omde_page = "True";
        } else {
            $omde_page = "False";
        }
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/sliders/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/sliders/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'addSlider?add=false'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'addSlider?add=error'; </script>";
            }
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://mondas.ir:4000/users/AddSliders',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('title' => "$title",'url' => "$url",'image' => "$image",'first_page' => "$first_page",'gold_page' => "$gold_page",'silver_page' => "$silver_page" ,'omde_page' => "$omde_page"),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
       
        $info = json_decode($response);
       

        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'sliders?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addSlider?add=unable'; </script>";
        }
    }
}

function editSliders($value){
    if(isset($_POST['edit'])){
        global $url;
        $title = $_POST['title'];
        $urlData = $_POST['url'];
         if (!empty($_POST['firstPage'])) {
            $first_page = "True";
        } else {
            $first_page = "False";
        }
        if (!empty($_POST['goldPage'])) {
            $gold_page = "True";
        } else {
            $gold_page = "False";
        }
        if (!empty($_POST['silverPage'])) {
            $silver_page = "True";
        } else {
            $silver_page = "False";
        }
        if (!empty($_POST['omdePage'])) {
            $omde_page = "True";
        } else {
            $omde_page = "False";
        }
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/sliders/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/sliders/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'editSlider?edit=false&id=$value'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'editSlider?edit=error&id=$value'; </script>";
            }
        }
        
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => "$url/users/EditSlider",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('title' => "$title",'url' => "$urlData",'image' => "$image",'first_page' => "$first_page",'gold_page' => "$gold_page",'silver_page' => "$silver_page",'id' => "$value",'omde_page' => "$omde_page"),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        
        
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'sliders?edit=true&id=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editSlider?edit=unable&id=$value'; </script>";
        }
    }
}

function deleteSliders($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/DeleteSliders",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'sliders?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'sliders?delete=false'; </script>";
    }
}

function getArticles(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/GetArticles",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addArticles(){
    if(isset($_POST['add'])){
        global $url;
        $name = $_POST['name'];
        $description = $_POST['description'];
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/articles/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/articles/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'addArticles?add=false'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'addArticles?add=error'; </script>";
            }
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/AddArticles",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('name' => "$name",'description' => "$description",'image' => "$image"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'articles?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addArticles?add=unable'; </script>";
        }
    }
}

function editArticles($value){
    if(isset($_POST['edit'])){
        global $url;
        $name = $_POST['name'];
        $description = $_POST['description'];
        $file = $_FILES['file'];
        if ($file['size'] > 0) {
            $ghesmate1 = explode('.', $file['name']);
            $ghesmate2 = end($ghesmate1);
            if (in_array($ghesmate2, ['jpg', 'JPG', 'png' , 'svg', 'PNG', 'jpeg', 'JPEG'])) {
                $ghesmate3 = microtime() . '.' . $ghesmate2;
                if (move_uploaded_file($file['tmp_name'], "/home/mondas/public_html/admin/uploads/articles/$ghesmate3")) {
                    $image = "http://mondas.ir/admin/uploads/articles/$ghesmate3";
                } else {
                    echo "<script type='text/javascript'> document.location = 'editArticle?add=false'; </script>";
                }

            } else {
                echo "<script type='text/javascript'> document.location = 'editArticle?add=error'; </script>";
            }
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/EditArticles",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('id' => "$value" , 'name' => "$name",'description' => "$description",'image' => "$image"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'articles?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editArticle?add=unable'; </script>";
        }
    }
}

function deleteArticles($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/DeleteArticles",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'articles?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'articles?delete=false'; </script>";
    }
}

function getAbout(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/GetAbout",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function editAbout($value){
    if(isset($_POST['edit'])){
        global $url;
        $phone1 = $_POST['phone1'];
        $phone2 = $_POST['phone2'];
        $phone3 = $_POST['phone3'];
        $addres = $_POST['addres'];
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/EditAbout",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('id' => "$value" , 'phone1' => "$phone1" , 'phone2' => "$phone2" , 'phone3' => "$phone3" , 'addres' => "$addres"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'aboutUs?edit=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editAbout?edit=unable&id=$value'; </script>";
        }
    }
}

function deleteAbout($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/DeleteAbout",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'aboutUs?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'aboutUs?delete=false'; </script>";
    }
}

function getUser(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/GetUsers",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addUser(){
    if(isset($_POST['add'])){
        global $url;
        $username = $_POST['username'];
        $fullName = $_POST['fullName'];
        $password = $_POST['password'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $amount = $_POST['amount'];
        if (!empty($_POST['role'])) {
            $role = "True";
        } else {
            $role = "False";
        }
        if (!empty($_POST['wholeSaler'])) {
            $wholeSaler = "True";
        } else {
            $wholeSaler = "False";
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/AddUsers",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => "$username",'password' => "$password",'user_full_name' => "$fullName",'address' => "$address",'phone' => "$phone",'email' => "$email",'amount' => "$amount" , 'role' => "$role" , 'wholesaler' => "$wholeSaler"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'users?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addUser?add=false'; </script>";
        }
    }
}

function editUser($value){
    if(isset($_POST['edit'])){
        global $url;
        $username = $_POST['username'];
        $fullName = $_POST['fullName'];
        $password = $_POST['password'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $amount = $_POST['amount'];
        if (!empty($_POST['role'])) {
            $role = "True";
        } else {
            $role = "False";
        }
        if (!empty($_POST['wholeSaler'])) {
            $wholeSaler = "True";
        } else {
            $wholeSaler = "False";
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/EditUsers",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => "$username",'password' => "$password",'user_full_name' => "$fullName",'address' => "$address",'phone' => "$phone",'email' => "$email",'amount' => "$amount" , 'id'=>"$value" , 'role' => "$role" , 'wholesaler' => "$wholeSaler"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'users?edit=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editUser?edit=false'; </script>";
        }
    }
}

function deleteUser($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/DeleteUsers",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'users?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'users?delete=false'; </script>";
    }
}

function getProductComment($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProductComments",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function deleteProductComment($value , $item){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeleteProductComment",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'Comment?delete=true&comment=$item'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'productComment?delete=false&comment=$item'; </script>";
    }
}

function getOrders(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetUserOrder",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        $all = [$info->data , $info->totalorder];
        return $all;
    } else {

    }
}

function deleteOrder($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeleteUserOrder",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'orders?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'orders?delete=false'; </script>";
    }
}

function editDailyPrice(){
    if(isset($_POST['add'])){
        global $url;
        $price = $_POST['price'];
        if (!empty($_POST['isGold'])) {
            $isGold = "True";
            $id = 1;
            } else {
            $isGold = "False";
            $id = 2;
            }
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/EditPrice",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$id",'price' => "$price",'is_gold' => "$isGold"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'product?changePrice=true'; </script>";
        } else {
        echo "<script type='text/javascript'> document.location = 'addGoldPrice?changePrice=false'; </script>";
        }
    }
}

function getFormula()
{
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetFormula",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data[0];
    } else {

    }
}


function editFormula(){
    if(isset($_POST['edit'])){
        global $url;
        $price1 = $_POST['price1'];
        $price2 = $_POST['price2'];
        $price3 = $_POST['price3'];
        $box = $_POST['box'];
        $send = $_POST['send'];
        $admin = $_POST['admin'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/EditFormula",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('id'=>'1' , 'price1' => "$price1" , 'price2' => "$price2" , 'price3' => "$price3" , 'box' => "$box" , 'send' => "$send" , 'admin' => "$admin"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'addFormula?change=true'; </script>";
        } else {
        echo "<script type='text/javascript'> document.location = 'addFormula?change=false'; </script>";
        }
    }
}

function getCart($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetCart",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        $all = [$info->data , $info->total];
        return $all;
    } else {

    }
}

function editOrder($value){
    if(isset($_POST['edit'])){
        global $url;
        if (!empty($_POST['isFinally'])) {
            $isFinally = "True";
            } else {
            $isFinally = "False";
            }
        $refId = $_POST['refId'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => "$url/products/EditUserOrder",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('is_finally' => "$isFinally",'id' => "$value",'ref_id' => "$refId"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'orders?change=true&id=$value'; </script>";
        } else {
        echo "<script type='text/javascript'> document.location = 'editOrder?change=false&id=$value'; </script>";
        }
    }
    
}

function getEmails(){
    global $url;
    
    $curl = curl_init();
    
    curl_setopt_array($curl, array(
      CURLOPT_URL => "$url/products/GetEmail",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    
    $response = curl_exec($curl);
    
    curl_close($curl);
    
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getFilters(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "$url/products/GetStatus",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function changeStatus($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "$url/products/ChangeStatus",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
        if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'filters?change=true'; </script>";
        } else {
        echo "<script type='text/javascript'> document.location = 'filters?change=false'; </script>";
        }
}

function addFilterDetails($value , $name){
    if(isset($_POST['add'])){
        global $url;
        $title = $_POST['title'];
        $count = count($title);
        $message = array();
        for ($i = 0; $i < $count; $i++) {
            $satr['Attribute'] = $title[$i];
            $satr['status'] = $value;
            $satr['name'] = $name;
            $satr['value'] = '';
            $message[] = $satr;
        }
        $data = json_encode($message);
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => "$url/products/AddAttribute",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>$data,
          CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'filterDetails?add=true&id=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'addFilterDetail?add=false&id=$value'; </script>";
        }
    }
}


function getFilterDetail($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "$url/products/GetAttribute",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => array('status' => "$value"),
    ));
    
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function deleteFilterDetail($value , $item){
    global $url;
    
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "$url/products/DeleteAttribute",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    
    $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'filterDetails?delete=true&id=$item'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'filterDetails?delete=false&id=$item'; </script>";
        }
}

function editAttribute($value , $item){
    if(isset($_POST['edit'])){
        global $url;
        $attribute = $_POST['attribute'];
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => "$url/products/EditAttribute",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('id' => "$value",'Attribute' => "$attribute"),
        ));
        
        $response = curl_exec($curl);
        curl_close($curl);
        
         $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'filterDetails?edit=true&id=$item'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'editFilterDetail?edit=false&id=$item'; </script>";
        }
    }
}






