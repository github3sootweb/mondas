<?php
include_once "include/include.php";
if(isset($_GET['id'])){
    
    if($_GET['id'] == 1){
        $name = "count";
    }elseif($_GET['id'] == 2){
        $name = "weight";
    }elseif($_GET['id'] == 5){
        $name = "offPercent";
    }elseif($_GET['id'] == 10){
        $name = "model";
    }elseif($_GET['id'] == 11){
        $name = "color";
    }
    
    addFilterDetails($_GET['id'] , $name);
}

if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

include_once "header.php";
?>
<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3> افزودن جزییات فیلتر  </h3>
                </div>
            </div>

            <div class="row layout-top-spacing">
                
                
                 <div class="col-lg-12 layout-spacing" style="display: none">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                            <h4>انتخاب 2 کوچک</h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area">
                                    <p> استفاده از <code>data('select2')</code> تابع برای بدست آوردن ظرف انتخاب 2.</p>
                                    <select class="form-control form-small">
                                        <option selected="selected">نارنجی</option>
                                        <option>سفید</option>
                                        <option>بنفش</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                <div class="col-lg-12 col-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-content widget-content-area">
                            <?php
                            if (isset($_GET['add'])) {
                                if ($_GET['add'] == "false") {
                                    echo "<h4 class='btn-danger btn btn-block text-white' style='margin-bottom: 10px;'>عملیات با موفقیت انجام نشد</h4>";
                                }
                            }
                            ?>
                            <form method="post" enctype="multipart/form-data">
                                <select class="form-control tagging" name="title[]" multiple="multiple">
                                    </select>
                                <button type="submit"  name="add" class="mt-4 mb-4 btn btn-primary">ارسال</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>

