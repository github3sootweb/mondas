<?php
include_once "include/include.php";

if(isset($_GET['id'])){
    $all = getCart($_GET['id']);
    $product = $all[0];
    $total = $all[1];
}

if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

include_once "header.php";
?>


<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3> سفارشات  </h3>
                </div>
            </div>

            <div class="row layout-top-spacing">

                <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                    
                    <a  class="col-xl-12 col-lg-12 col-sm-12">
                        <div class="btn btn-success mb-3 " >
                            کل مبلغ سبدخرید:<?php echo number_format($total);  ?>ریال
                        </div>
                    </a>
                    
                    <div class="widget-content widget-content-area br-6">
                        <div class="table-responsive mb-4 mt-4">
                            <table id="html5-extension" class="table table-hover non-hover" style="width:100%">
                                
                                <thead>
                                <tr>
                                    <th> نام محصول</th>
                                    <th>مبلغ</th>
                                    <th>تصویر</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                if(!empty($product)){
                                foreach ($product as $item){
                                ?>
                                <tr>
                                    <td><?php echo $item->product_name ?></td>
                                    <td><?php echo number_format($item->price) ?>ریال</td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo $item->image[0]->image  ?>">
                                            <div class="mr-2 rounded-circle">
                                                <img alt="avatar" class="img-fluid rounded-circle"
                                                     src="<?php echo $item->image[0]->image  ?>" width="100" height="100">
                                            </div>
                                            </a>
                                        </div>
                                    </td>
                                    
                                </tr>
                                <?php } } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>

