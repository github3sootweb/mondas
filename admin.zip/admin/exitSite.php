<?php
setcookie("id", "", time() - 3600);
echo "<script type='text/javascript'> document.location = 'managementLogin.php'; </script>";
?>