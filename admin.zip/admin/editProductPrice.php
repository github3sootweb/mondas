<?php
include_once "include/include.php";
if(isset($_GET['price']) && isset($_GET['id'])){
    $user = getUser();
    $data = getDataById($_GET['id'] , 'products/GetProductPrice');
    editProductPrice($_GET['price'] , $_GET['id']);
}
if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

include_once "header.php";
?>
<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3>  قیمت محصول </h3>
                </div>
            </div>

            <div class="row layout-top-spacing">

                <div class="col-lg-12 col-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-content widget-content-area">
                            <?php
                            if (isset($_GET['edit'])) {
                                if ($_GET['edit'] == "false") {
                                    echo "<h4 class='btn-danger btn btn-block text-white' style='margin-bottom: 10px;'>  عملیات با موفقیت انجام نشد </h4>";
                                }
                            }
                            ?>
                            <form method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="form-group mb-4 col-xl-6 col-md-6 col-sm-6 col-12">
                                        <label for="exampleFormControlInput2">  لیست کاربران  </label>
                                        <select class="form-control" name="userId">
                                            <?php
                                            if(!empty($user)){
                                                foreach($user as $value){
                                                    ?>
                                                    <option value="<?php echo $value->id  ?>" <?Php if($data->user_id == $value->id){echo 'selected';}  ?>><?php  echo $value->username ?></option>
                                                <?php  } } ?>
                                        </select>
                                    </div>
                                    <div class="form-group mb-4 col-xl-6 col-md-6 col-sm-6 col-12">
                                        <label for="exampleFormControlInput2"> مبلغ</label>
                                        <input type="number" class="form-control" name="price"
                                               id="exampleFormControlInput2" value="<?php echo $data->price ?>">
                                    </div>

                                </div>
                                <button type="submit"  name="edit" class="mt-4 mb-4 btn btn-primary">ویرایش</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>

