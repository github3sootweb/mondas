<?php
include_once "include/include.php";
$all = getProduct();
$product = $all[0];
$goldPrice = $all[1];
$silverPrice = $all[2];

if(isset($_GET['opt'])){
    deleteProduct($_GET['opt']);
}

if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

include_once "header.php";
?>


<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3>   محصولات</h3>
                </div>
            </div>

            <div class="row layout-top-spacing">

                <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                    <div class="row">
                    <a href="addProduct" class="col-xl-4 col-lg-4 col-sm-4">
                        <div class="btn btn-success mb-3 w-100" >
                            افزودن
                        </div>
                    </a>
                    <a href="addGoldPrice" class="col-xl-4 col-lg-4 col-sm-4">
                        <div class="btn btn-primary w-100 mb-3">
                            ویرایش قیمت روز
                        </div>
                    </a>
                    <a href="addFormula" class="col-xl-4 col-lg-4 col-sm-4">
                        <div class="btn btn-danger w-100 mb-3">
                            قیمت های فرمول  
                        </div>
                    </a>
                    </div>
                    
                    <div class="row">
                    <a  class="col-xl-6 col-lg-6 col-sm-6 ">
                        <div class="btn w-100 mb-3"  style="height:60px;font-size:1.5em;background-color:#ffdd1e
 !important;">
                            قیمت روز طلا:<?php echo number_format($goldPrice)  ?>ریال
                        </div>
                    </a>
                    
                    
                    <a  class="col-xl-6 col-lg-6 col-sm-6">
                        <div class="btn w-100 mb-3" style="height:60px;font-size:1.5em;background-color:#979797 !important;">
                            قیمت روز نقره:<?php   echo number_format($silverPrice) ?>ریال
                        </div>
                    </a>
                    
                
                    </div>
                    
                    
                    <div class="widget-content widget-content-area br-6">
                        <div class="table-responsive mb-4 mt-4">
                            <table id="html5-extension" class="table table-hover non-hover" style="width:100%;overflow: scroll">
                                <?php
                                if (isset($_GET['change'])) {
                                    echo "<h4 class='btn-primary btn btn-block text-white'>عملیات با موفقیت انجام شد</h4>";
                                }
                                if (isset($_GET['add'])) {
                                    echo "<h4 class='btn-primary btn btn-block text-white'>عملیات با موفقیت انجام شد</h4>";
                                }
                                if (isset($_GET['delete'])) {
                                    if ($_GET['delete'] == "false") {
                                        echo "<h4 class='btn-danger btn btn-block text-white'>عملیات با موفقیت انجام نشد</h4>";
                                    }elseif($_GET['delete'] == "true"){
                                        echo "<h4 class='btn-primary btn btn-block text-white'>عملیات با موفقیت انجام شد</h4>";
                                    }
                                }
                                if (isset($_GET['changePrice'])) {
                                    if ($_GET['changePrice'] == "false") {
                                        echo "<h4 class='btn-danger btn btn-block text-white'>عملیات با موفقیت انجام نشد</h4>";
                                    }elseif($_GET['changePrice'] == "true"){
                                        echo "<h4 class='btn-primary btn btn-block text-white'>عملیات با موفقیت انجام شد</h4>";
                                    }
                                }
                                ?>
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th> نام</th>
                                    <th> دسته بندی</th>
                                    <th>توضیحات</th>
                                    <th>تعداد</th>
                                    <th>قیمت</th>
                                    <th>تخفیف دارد؟</th>
                                    <th> درصد تخفیف</th>
                                    <th> وزن </th>
                                    <th> طلا است؟ </th>
                                    <th> عیار </th>
                                    <th> جنسیت </th>
                                    <th> مدل </th>
                                    <th> رنگ </th>
                                    <th> کالکشن </th>
                                    <th> بازدید </th>
                                    <th>عمل</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                if(!empty($product)){
                                    foreach ($product as $item){
                                        ?>
                                        <tr>
                                            <td><?php echo $item->id ?></td>
                                            <td><?php echo $item->name ?></td>
                                            <td><?php echo $item->category ?></td>
                                            <td><?php echo $item->description ?></td>
                                            <td><?php echo $item->count ?></td>
                                            <td><?php echo number_format($item->price) ?>ریال</td>
                                            <td><?php
                                                if($item->is_off == True){
                                                    echo "<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-activity'><polyline points='9 11 12 14 23 3'></polyline><path d='M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'></path></svg>";
                                                }else{
                                                    echo "<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-activity'><rect x='3' y='3' width='18' height='18' rx='2' ry='2'></rect><line x1='9' y1='9' x2='15' y2='15'></line><line x1='15' y1='9' x2='9' y2='15'></line></svg>";
                                                }?></td>
                                            <td>%<?php echo $item->off_percent ?></td>
                                            <td><?php echo $item->weight ?>گرم</td>
                                            <td><?php
                                                if($item->is_gold == True){
                                                    echo "<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-activity'><polyline points='9 11 12 14 23 3'></polyline><path d='M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'></path></svg>";
                                                }else{
                                                    echo "<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-activity'><rect x='3' y='3' width='18' height='18' rx='2' ry='2'></rect><line x1='9' y1='9' x2='15' y2='15'></line><line x1='15' y1='9' x2='9' y2='15'></line></svg>";
                                                }?></td>
                                            <td><?php echo $item->gold_carat ?>عیار</td>
                                            <td><?php 
                                            if($item->gender == "men"){
                                                echo "مردانه";
                                            }elseif($item->gender == "women"){
                                                echo "زنانه";
                                            }elseif($item->gender == "both"){
                                                echo "هردو";
                                            }
                                            ?></td>
                                            <td><?php echo $item->model ?></td>
                                            <td><?php echo $item->color ?></td>
                                            <td><?php echo $item->colaction ?></td>
                                            <td><?php echo $item->seen ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-dark btn-sm">بیشتر</button>
                                                    <button type="button"
                                                            class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split"
                                                            id="dropdownMenuReference1" data-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                             stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                             class="feather feather-chevron-down">
                                                            <polyline points="6 9 12 15 18 9"></polyline>
                                                        </svg>
                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                                                        <a class="dropdown-item" href="editProduct?edit=<?php echo $item->id ?>">ویرایش</a>
                                                        <a class="dropdown-item" href="Images?image=<?php echo $item->id ?>">تصاویر محصول</a>
                                                        <a class="dropdown-item" href="Price?price=<?php echo $item->id ?>">مبالغ محصول</a>
                                                        <a class="dropdown-item" href="Comment?comment=<?php echo $item->id ?>">نظرات محصول</a>
                                                        <div class="dropdown-divider"></div>
                                                        <a class="dropdown-item" href="product?opt=<?php echo $item->id ?>"> حذف</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php } } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>

