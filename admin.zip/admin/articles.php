<?php
include_once "include/include.php";
$article = getArticles();

if(isset($_GET['opt'])){
    deleteArticles($_GET['opt']);
}

if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

include_once "header.php";
?>


<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3> مطالب  </h3>
                </div>
            </div>

            <div class="row layout-top-spacing">

                <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                    <a href="addArticles">
                        <div class="btn btn-success col-xl-3 col-lg-3 col-sm-3 mb-3">
                            افزودن
                        </div>
                    </a>
                    <div class="widget-content widget-content-area br-6">
                        <div class="table-responsive mb-4 mt-4">
                            <table id="html5-extension" class="table table-hover non-hover" style="width:100%">
                                <?php
                                if (isset($_GET['edit'])) {
                                    echo "<h4 class='btn-primary btn btn-block text-white'>عملیات با موفقیت انجام شد</h4>";
                                }
                                if (isset($_GET['add'])) {
                                    echo "<h4 class='btn-primary btn btn-block text-white'>عملیات با موفقیت انجام شد</h4>";
                                }
                                if (isset($_GET['delete'])) {
                                    if ($_GET['delete'] == "false") {
                                        echo "<h4 class='btn-danger btn btn-block text-white'>عملیات با موفقیت انجام نشد</h4>";
                                    }elseif($_GET['delete'] == "true"){
                                        echo "<h4 class='btn-primary btn btn-block text-white'>عملیات با موفقیت انجام شد</h4>";
                                    }
                                }
                                ?>
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th> نام</th>
                                    <th> توضیحات</th>
                                    <th>تصویر</th>
                                    <th>عمل</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                if(!empty($article)){
                                    foreach ($article as $item){
                                        ?>
                                        <tr>
                                            <td><?php echo $item->id ?></td>
                                            <td><?php echo $item->name ?></td>
                                            <td><?php echo $item->description ?></td>
                                            <td>
                                                <div class="d-flex">
                                                    <a href="<?php echo $item->image ?>">
                                                    <div class="mr-2 rounded-circle">
                                                        <img alt="avatar" class="img-fluid rounded-circle"
                                                             src="<?php echo $item->image ?>" width="100" height="100">
                                                    </div>
                                                    </a>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-dark btn-sm">بیشتر</button>
                                                    <button type="button"
                                                            class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split"
                                                            id="dropdownMenuReference1" data-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                             stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                             class="feather feather-chevron-down">
                                                            <polyline points="6 9 12 15 18 9"></polyline>
                                                        </svg>
                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                                                        <a class="dropdown-item" href="editArticle?id=<?php echo $item->id ?>">ویرایش</a>
                                                        <div class="dropdown-divider"></div>
                                                        <a class="dropdown-item" href="articles?opt=<?php echo $item->id ?>"> حذف</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php } } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>

