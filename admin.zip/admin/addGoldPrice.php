<?php
include_once "include/include.php";

editDailyPrice();

if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

include_once "header.php";
?>
<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3>  کاربران </h3>
                </div>
            </div>

            <div class="row layout-top-spacing">

                <div class="col-lg-12 col-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-content widget-content-area">
                            <?php
                            if (isset($_GET['add'])) {
                                if ($_GET['add'] == "false") {
                                    echo "<h4 class='btn-danger btn btn-block text-white' style='margin-bottom: 10px;'>  عملیات با موفقیت انجام نشد </h4>";
                                }
                            }
                            ?>
                            <form method="post" enctype="multipart/form-data">
                                <div class="row">

                                    <div class="form-group mb-4 col-xl-12 col-md-12 col-sm-12 col-12">
                                        <label for="exampleFormControlSelect1"> قیمت روز طلا </label>
                                        <input type="number" class="form-control" name="price"
                                               id="exampleFormControlInput2">
                                    </div>
                                    

                                </div>
                                <div class="n-chk col-xl-4 col-md-4 col-sm-4 col-4">
                                        <label class="new-control new-checkbox checkbox-primary">
                                            <input type="checkbox" name="isGold" class="new-control-input">
                                            <span class="new-control-indicator"></span>   آیا این قیمت طلا باشد؟
                                        </label>
                                    </div>
                                


                                <button type="submit"  name="add" class="mt-4 mb-4 btn btn-primary">افزودن</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>

