<?php
include_once "include/include.php";
$category = getCategories();
$collaction = getCollactions();

if(isset($_GET['edit'])){
    $data = getDataById($_GET['edit'] , 'products/GetProducts');
    editProduct($_GET['edit']);
}

if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

include_once "header.php";
?>
<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3>  محصولات </h3>
                </div>
            </div>

            <div class="row layout-top-spacing">

                <div class="col-lg-12 col-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-content widget-content-area">
                            <?php
                            if (isset($_GET['change'])) {
                                if ($_GET['change'] == "false") {
                                    echo "<h4 class='btn-danger btn btn-block text-white' style='margin-bottom: 10px;'>عملیات با موفقیت انجام نشد</h4>";
                                }
                            }
                            ?>
                            <form method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlInput2">  لیست دسته بندی ها</label>
                                        <select class="form-control" name="categoryId">
                                            <?php
                                            if(!empty($category)){
                                                foreach($category as $value){
                                                    ?>
                                                    <option value="<?php echo $value->id  ?>" <?Php if($data->category_id == $value->id){echo 'selected';}  ?>><?php  echo $value->title ?> - <?php if($value->gold == "true"){ echo "طلا";}else{ echo "نقره"; } ?>  </option>
                                                <?php  } } ?>
                                        </select>
                                    </div>
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlSelect1"> نام</label>
                                        <input type="text" class="form-control" name="name"
                                               id="exampleFormControlInput2" value="<?php echo $data->name ?>">
                                    </div>
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlSelect1"> تعداد</label>
                                        <input type="number" class="form-control" name="count"
                                               id="exampleFormControlInput2" value="<?php echo $data->count ?>">
                                    </div>
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlSelect1"> تخفیف </label>
                                        <select class="form-control" name="is_off">
                                            <option value="True" <?Php if($data->is_off == true){echo 'selected';}  ?>>دارد</option>
                                            <option value="False"  <?Php if($data->is_off == false){echo 'selected';}  ?>>ندارد</option>
                                        </select>
                                    </div>
                                </div>
                              
                                <div class="row">
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlInput2"> جنس</label>
                                        
                                        <select class="form-control" name="gens">
                                            <option value="men" <?php if($data->gender == "men") {echo 'selected';}  ?>>مردانه </option>
                                            <option value="women" <?php if($data->gender == "women") {echo 'selected';}  ?>>زنانه </option>
                                            <option value="both" <?php if($data->gender == "both") {echo 'selected';}  ?>>هردو </option>
                                        </select>
                                    </div>
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlInput2"> مدل</label>
                                        <input type="text" class="form-control" name="model"
                                               id="exampleFormControlInput2" value="<?php echo $data->model ?>">
                                    </div>
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlSelect1"> رنگ </label>
                                        <input type="text" class="form-control" name="color"
                                               id="exampleFormControlInput2" value="<?php echo $data->color ?>">
                                    </div>
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlSelect1"> طلا یا نقره </label>
                                        <select class="form-control" name="is_gold">
                                            <option value="False" <?Php if($data->is_gold == "False"){echo 'selected';}  ?>> نقره </option>
                                            <option value="True" <?Php if($data->is_gold == "True"){echo 'selected';}  ?>>طلا </option>
                                        </select>
                                    </div>
                                </div>
                                  <div class="row">
                                
                                    <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlSelect1"> درصد تخفیف</label>
                                        <input type="number" class="form-control" name="offPercent"
                                               id="exampleFormControlInput2" value="<?php echo $data->off_percent ?>">
                                    </div>
                                    <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlSelect1"> وزن </label>
                                        <input name="weight"
                                               class="form-control"
                                               type="text" value="<?php echo $data->weight ?>">
                                    </div>
                                    <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlSelect1"> عیار </label>
                                        <select class="form-control" name="gold_carat">
                                            <option value="18" <?Php if($data->gold_carat == "18"){echo 'selected';}  ?>>۱۸ عیار</option>
                                            <option value="24" <?Php if($data->gold_carat == "24"){echo 'selected';}  ?>>۲۴ عیار</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group mb-4 col-xl-3 col-md-3 col-sm-3 col-12">
                                        <label for="exampleFormControlInput2">  لیست کالکشن ها  </label>
                                        <select class="form-control" name="collactionId">
                                            <?php
                                            if(!empty($collaction)){
                                                foreach($collaction as $value){
                                                    ?>
                                                    <option value="<?php echo $value->id  ?>"  <?Php if($data->colaction_id == $value->id){echo 'selected';}  ?>><?php  echo $value->title ?> - <?php if($value->gold == "true"){ echo "طلا";}else{ echo "نقره"; } ?>   </option>
                                                <?php  } } ?>
                                        </select>
                                    </div>
                                    <div class="form-group mb-4 col-xl-9 col-md-9 col-sm-9 col-12">
                                        <label for="exampleFormControlTextarea1"> توضیحات</label>
                                        <textarea class="form-control" name="description" id="exampleFormControlTextarea1"
                                                  rows="1"> <?php echo $data->description ?> </textarea>
                                    </div>
                                </div>

                                <button type="submit"  name="edit" class="mt-4 mb-4 btn btn-primary">ویرایش</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>


