<?php
include_once "include/include.php";
if(isset($_GET['edit'])){
    $data = getDataById($_GET['edit'] , 'products/GetCategories');
    editCategories($_GET['edit']);
}

if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

include_once "header.php";
?>
<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3> دسته بندی ها</h3>
                </div>
            </div>

            <div class="row layout-top-spacing">

                <div class="col-lg-12 col-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-content widget-content-area">
                            <?php
                            if (isset($_GET['change'])) {
                                if ($_GET['change'] == "false") {
                                    echo "<h4 class='btn-danger btn btn-block text-white' style='margin-bottom: 10px;'>آپلود عکس انجام نشد</h4>";
                                }elseif($_GET['change'] == "true"){
                                    echo "<h4 class='btn-primary btn btn-block text-white' style='margin-bottom: 10px;'>عملیات با موفقیت انجام شد</h4>";
                                }elseif($_GET['change'] == "error"){
                                    echo "<h4 class='btn-warning btn btn-block text-white' style='margin-bottom: 10px;'>  فرمت مورد نظر قابل قبول نیست</h4>";
                                }elseif($_GET['change'] == "unable"){
                                    echo "<h4 class='btn-danger btn btn-block text-white' style='margin-bottom: 10px;'>عملیات مورد نظر با موفقیت انجام نشد</h4>";
                                }
                            }
                            ?>
                            <form method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="form-group col-xl-12 col-md-12 col-sm-12 col-12 mb-4">
                                        <label for="exampleFormControlInput2">عنوان</label>
                                        <input type="text" name="title" class="form-control" id="exampleFormControlInput2" value="<?php echo $data->title ?>">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label for="exampleFormControlTextarea1">توضیحات</label>
                                    <textarea name="description" class="form-control" id="exampleFormControlTextarea1" rows="3"><?php echo $data->description ?></textarea>
                                </div>
                                 <div class="n-chk col-xl-4 col-md-4 col-sm-4 col-4">
                                        <label class="new-control new-checkbox checkbox-primary">
                                            <input type="checkbox" name="gold" class="new-control-input" <?php if($data->gold == "True"){
                                                echo 'checked';
                                            }  ?> >
                                            <span class="new-control-indicator"></span> آیا دسته بندی طلا است؟  
                                        </label>
                                </div>
                                <div class="form-group mb-4 mt-3">
                                    <label for="exampleFormControlFile1"> آپلود تصویر </label>
                                    <input type="file" name="file" class="form-control-file" id="exampleFormControlFile1">
                                </div>
                                <button type="submit"  name="edit" class="mt-4 mb-4 btn btn-primary">ارسال</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>


