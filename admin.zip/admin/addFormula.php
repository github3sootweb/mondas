<?php
include_once "include/include.php";

if(!isset($_COOKIE['id'])){
    echo "<script type='text/javascript'> document.location = 'managementLogin'; </script>";
}

$formule = getFormula();

editFormula();

include_once "header.php";
?>
<body class="sidebar-noneoverflow dashboard-sales">
<!-- BEGIN LOADER -->
<div id="load_screen">
    <div class="loader">
        <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div>
    </div>
</div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php include_once "navbar.php" ?>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php include_once "sidebar.php" ?>
    <!--  END SIDEBAR  -->

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3>  کاربران </h3>
                </div>
            </div>

            <div class="row layout-top-spacing">

                <div class="col-lg-12 col-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-content widget-content-area">
                            <?php
                            if (isset($_GET['change'])) {
                                if ($_GET['change'] == "false") {
                                    echo "<h4 class='btn-danger btn btn-block text-white' style='margin-bottom: 10px;'>  عملیات با موفقیت انجام نشد </h4>";
                                } elseif($_GET['change'] == "true"){
                                    echo "<h4 class='btn-success btn btn-block text-white' style='margin-bottom: 10px;'>  عملیات با موفقیت انجام شد </h4>";
                                }
                            }
                            ?>
                            <form method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlSelect1">   سایر هزینه ها ۱(n) </label>
                                        <input type="number" class="form-control" name="price1"
                                               id="exampleFormControlInput2" value="<?php echo $formule->price1  ?>" required>
                                    </div>
                                    <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlSelect1">  سایر هزینه ها ۲(A) </label>
                                        <input type="number" class="form-control" name="price2"
                                               id="exampleFormControlInput2" value="<?php echo $formule->price2  ?>" required>
                                    </div>
                                     <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlSelect1">  سایر هزینه ها ۳(B) </label>
                                        <input type="number" class="form-control" name="price3"
                                               id="exampleFormControlInput2" value="<?php echo $formule->price3  ?>" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlInput2"> هزینه جعبه</label>
                                        <input type="number" class="form-control" name="box"
                                               id="exampleFormControlInput2" value="<?php echo $formule->box  ?>">
                                    </div>
                                    <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlSelect1">  هزینه ارسال </label>
                                        <input type="number" class="form-control" name="send"
                                               id="exampleFormControlInput2" value="<?php echo $formule->send  ?>">
                                    </div>
                                    <div class="form-group mb-4 col-xl-4 col-md-4 col-sm-4 col-12">
                                        <label for="exampleFormControlSelect1"> هزینه ادمین </label>
                                        <input name="admin"
                                               class="form-control"
                                               type="number" value="<?php echo $formule->admin  ?>">
                                    </div>
                                </div>
                                
                                <button type="submit"  name="edit" class="mt-4 mb-4 btn btn-primary">تغییر قیمت ها</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!--  END CONTENT AREA  -->

</div>

<?php include_once "footer.php" ?>

