<?php
header('location:home');
?>