<?php
include_once "../controller/controller.php";
$slider = getSliders('omde_page');
$category = getCategories();
$collection = getCollactions();
if(isset($_COOKIE['id'])){
    $product = getProductByUserId();
}
signInWholeSaler();

$all = getAccess();

$access = $all[1];

$data = $all[0];
$color = $data[1];
$model = $data[2];
$offPercent = $data[7];
$weight = $data[10];
$count = $data[11];

if (isset($_GET['search'])) {
    $product = searchProductByUserId($_GET['search']);

} elseif (isset($_POST['filter'])) {
    $product = filterWholeData();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه اصلی</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/css/swiper.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://mondas.ir/site/wholeTala/assets/css/style.css">
</head>

<body>
<header id="Site-Header">
    <div class="header-top container-xl py-1">
        <div class="row">
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-sign d-flex align-items-center h-100">
                    <?php if (isset($_COOKIE['name'])) : ?>
                        <button class="sign-btn btn cta-btn rounded-pill" data-toggle="modal"
                                data-target="#logoutmodal">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo $_COOKIE['name']; ?>
                                </span>
                        </button>
                        <!-- Modal: Logout Start -->
                        <div class="modal fade" id="logoutmodal" tabindex="-1" aria-labelledby="logoutmodalLabel"
                             aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">خروج از حساب کاربری</h5>
                                    </div>
                                    <div class="modal-body">
                                        <p class="mb-0">خارج می‌شوید؟</p>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">ادامه
                                            در سایت
                                        </button>
                                        <a href="logout" class="btn btn-danger">خروج</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Logout End -->
                    <?php else : ?>
                        <button class="sign-btn btn cta-btn rounded-pill" data-toggle="modal"
                                data-target="#modalLRForm">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo "ورود"; ?>
                                </span>
                        </button>
                        <!-- Modal: Login / Register Start -->
                        <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog"
                             aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#login-tab" role="tab">
                                                <i class="fas fa-user ml-1"></i>ورود</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <!--- login --->
                                        <div class="tab-pane fade in show active" id="login-tab" role="tabpanel">
                                            <div class="modal-body mb-1">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" name="username"
                                                               id="email-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-login">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password"
                                                               id="password-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-login">رمز عبور</label>
                                                    </div>

                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signIn"
                                                                type="submit">ورود
                                                            <i class="fas fa-user ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="options text-center text-md-right mt-1">
                                                </div>
                                                <button type="button" class="btn btn-outline-danger mr-auto"
                                                        data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Login / Register End -->
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6 col-md-4 col-6">
                <div class="logo d-flex align-items-center justify-content-center h-100">
                    <a href="" class="d-block"><img src="http://mondas.ir/site/wholeTala/assets/images/logo.png"></a>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-search d-flex align-items-center justify-content-end h-100">
                    <form class="search-form position-relative d-none d-md-block w-100" method="GET"
                          action="whole?search=<?php echo $_GET['search'] ?>">
                        <input class="form-control rounded-pill" type="search" name="search" placeholder="جستجو..."
                               aria-label="Search">
                        <button class="btn position-absolute" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>
                    <div class="w-100 text-left d-block d-md-none">
                        <button class="btn cta-btn mobile-search-btn rounded-pill">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="mobile-search position-absolute w-100 py-4 bg-white">
                <div class="container">
                    <div class="row">
                        <span class="close-search tm-color col-2">بستن</span>
                        <div class="col-10">
                            <form class="search-form position-relative d-block d-md-none w-100" method="GET"
                                  action="whole?search=<?php echo $_GET['search'] ?>">
                                <input class="form-control" type="search" name="search" placeholder="جستجو..."
                                       aria-label="Search">
                                <button class="btn position-absolute" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom container-xl py-2">
        <div class="row">
            <div class="col-sm-3 col-6 header-nav-icons">
                <a href="whole">
                    <i class="fa fa-home ml-3"></i>
                </a>
                <a href="hamper">
                    <i class="fa fa-shopping-cart"></i>
                </a>
            </div>
            <?php if (isset($_COOKIE['amount'])) { ?>
                <div class="col-sm-9 col-6">
                    <div class="header-sign d-flex align-items-center justify-content-end h-100">
                        <a href="#" class="cta-btn btn rounded-pill">موجودی <?php echo $_COOKIE['amount'] ?> ریال</a>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>

</header>


<main>
    <section class="slider-area container-fluid">
        <div class="home-slider swiper-container">
            <div class="swiper-wrapper">
                <?php
                if (!empty($slider)) {
                    foreach ($slider as $item) {
                        ?>
                        <div class="swiper-slide">
                            <img src="<?php echo $item->image ?>">
                            <div class="slider-content">
                                <h2 class="slider-element text-light"><?php echo $item->title ?></h2>
                            </div>
                        </div>
                    <?php }
                } ?>

            </div>
            <div class="home-slider-pagination swiper-pagination"></div>
            <div class="home-slider-button-next swiper-button-next"></div>
            <div class="home-slider-button-prev swiper-button-prev"></div>
        </div>
    </section>
    <div id="Site-Wrapper" class="container-xl">
        <div class="row py-3 py-md-5">
            <div class="shop-side col-xl-3 col-md-4 pb-5 pb-md-0">
                <div class="boxes ">
                    <form class="accordion filter-product" id="filterProduct" method="post">
                        <div class="inner-wrapper">
                            <?php if ($access[4]->قیمت == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                    <div class="card-header border-0 bg-transparent" id="heading-1"
                                         data-toggle="collapse"
                                         data-target="#collapse-1" aria-expanded="true" aria-controls="collapse-1">
                                                       <span class="font-weight-bold align-items-center d-flex justify-content-between no-focus">
                                                            بیشترین قیمت<i class="fa fa-plus"></i>
                                                       </span>
                                    </div>

                                    <div id="collapse-1" class="collapse show" aria-labelledby="heading-1"
                                         data-parent="#filterProduct">
                                        <div class="card-body">
                                            <input type="range" name="range" class="form-control-range"
                                                   id="priceControlRange" min="0" max="300000" step="10000"
                                                   value="300000">
                                            <output for="priceControlRange" class="output"></output>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            if ($access[9]->جنسیت == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                    <div class="card-header border-0 bg-transparent" id="heading-2"
                                         data-toggle="collapse"
                                         data-target="#collapse-2" aria-expanded="false" aria-controls="collapse-2">
                                                       <span class="font-weight-bold align-items-center d-flex justify-content-between no-focus">
                                                            براساس جنسیت<i class="fa fa-plus"></i>
                                                       </span>
                                    </div>

                                    <div id="collapse-2" class="collapse" aria-labelledby="heading-2"
                                         data-parent="#filterProduct">
                                        <div class="card-body">
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox"
                                                       name="gender"
                                                       value="men" id="filterageMen">
                                                <label for="filterageMen">
                                                    <span class="check-span"></span>
                                                    مردانه
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox"
                                                       name="gender"
                                                       value="women" id="filterageWomen">
                                                <label for="filterageWomen">
                                                    <span class="check-span"></span>
                                                    زنانه
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox"
                                                       name="gender"
                                                       value="both" id="filterageAllGenders">
                                                <label for="filterageAllGenders">
                                                    <span class="check-span"></span>
                                                    هردو
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            if ($access[5]->دسته == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                    <div class="font-weight-bold card-header border-0 bg-transparent" id="heading-3"
                                         data-toggle="collapse" data-target="#collapse-3" aria-expanded="false"
                                         aria-controls="collapse-3">
                                                       <span class="align-items-center d-flex justify-content-between no-focus">
                                                            براساس دسته بندی<i class="fa fa-plus"></i>
                                                       </span>
                                    </div>
                                    <div id="collapse-3" class="collapse" aria-labelledby="heading-3"
                                         data-parent="#filterProduct">
                                        <div class="card-body">
                                            <?php
                                            if (!empty($category)) {
                                                foreach ($category as $item) {
                                                    ?>
                                                    <div class="checkbox">
                                                        <input class="form-check-input" type="checkbox"
                                                               name="category[]"
                                                               value="<?php echo $item->id ?>"
                                                               id="filtertype1<?php echo $item->id ?>">
                                                        <label for="filtertype1<?php echo $item->id ?>">
                                                            <span class="check-span"></span>
                                                            <?php echo $item->title ?>
                                                        </label>
                                                    </div>
                                                <?php }
                                            } ?>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            if ($access[6]->جنس == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                    <div class="card-header border-0 bg-transparent" id="heading-4"
                                         data-toggle="collapse"
                                         data-target="#collapse-4" aria-expanded="false" aria-controls="collapse-4">
                                                       <span class="font-weight-bold align-items-center d-flex justify-content-between no-focus">
                                                            براساس نوع<i class="fa fa-plus"></i>
                                                       </span>
                                    </div>

                                    <div id="collapse-4" class="collapse" aria-labelledby="heading-4"
                                         data-parent="#filterProduct">
                                        <div class="card-body">
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox"
                                                       name="gens"
                                                       value="True" id="filtertypeGold">
                                                <label for="filtertypeGold">
                                                    <span class="check-span"></span>طلا
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox"
                                                       name="gens"
                                                       value="False" id="filtertypeSilver">
                                                <label for="filtertypeSilver">
                                                    <span class="check-span"></span>نقره
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            if ($access[8]->تخفیف == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                    <div class="card-header border-0 bg-transparent" id="heading-5"
                                         data-toggle="collapse"
                                         data-target="#collapse-5" aria-expanded="false" aria-controls="collapse-5">
                                                       <span class="font-weight-bold align-items-center d-flex justify-content-between no-focus">
                                                            براساس تخفیف<i class="fa fa-plus"></i>
                                                       </span>
                                    </div>

                                    <div id="collapse-5" class="collapse" aria-labelledby="heading-5"
                                         data-parent="#filterProduct">
                                        <div class="card-body">
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox" name="off"
                                                       value="True" id="filtertypeOff">
                                                <label for="filtertypeOff">
                                                    <span class="check-span"></span>دارد
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox" name="off"
                                                       value="False" id="filtertypeNoOff">
                                                <label for="filtertypeNoOff">
                                                    <span class="check-span"></span>ندارد
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            if ($access[0]->کالکشن == 1) {?>
                                <div class="card border-0 mb-2 mb-md-4">
                                <div class="font-weight-bold card-header border-0 bg-transparent" id="heading-6"
                                     data-toggle="collapse" data-target="#collapse-6" aria-expanded="false"
                                     aria-controls="collapse-6">
                                                       <span class="align-items-center d-flex justify-content-between no-focus">
                                                            براساس کالکشن<i class="fa fa-plus"></i>
                                                       </span>
                                </div>
                                <div id="collapse-6" class="collapse" aria-labelledby="heading-6"
                                     data-parent="#filterProduct">
                                    <div class="card-body">
                                        <?php
                                        if (!empty($collection)) {
                                            foreach ($collection as $item) {
                                                ?>
                                                <div class="checkbox">
                                                    <input class="form-check-input" type="checkbox"
                                                           name="collection[]"
                                                           value="<?php echo $item->id ?>"
                                                           id="filtertype11<?php echo $item->id ?>">
                                                    <label for="filtertype11<?php echo $item->id ?>">
                                                        <span class="check-span"></span>
                                                        <?php echo $item->title ?>
                                                    </label>
                                                </div>
                                            <?php }
                                        } ?>
                                    </div>
                                </div>
                            </div>
                            <?php }
                            if ($access[3]->عیار == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                    <div class="card-header border-0 bg-transparent" id="heading-7"
                                         data-toggle="collapse"
                                         data-target="#collapse-7" aria-expanded="false" aria-controls="collapse-7">
                                                       <span class="font-weight-bold align-items-center d-flex justify-content-between no-focus">
                                                            براساس عیار<i class="fa fa-plus"></i>
                                                       </span>
                                    </div>

                                    <div id="collapse-7" class="collapse" aria-labelledby="heading-7"
                                         data-parent="#filterProduct">
                                        <div class="card-body">
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox" name="carat"
                                                       value="18" id="filtertype18">
                                                <label for="filtertype18">
                                                    <span class="check-span"></span>۱۸عیار
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <input class="form-check-input once-checkbox" type="checkbox" name="carat"
                                                       value="24" id="filtertype24">
                                                <label for="filtertype24">
                                                    <span class="check-span"></span>۲۴عیار
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            if ($access[11]->تعداد == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                <div class="font-weight-bold card-header border-0 bg-transparent" id="heading-8"
                                     data-toggle="collapse" data-target="#collapse-8" aria-expanded="false"
                                     aria-controls="collapse-8">
                                                       <span class="align-items-center d-flex justify-content-between no-focus">
                                                            براساس تعداد<i class="fa fa-plus"></i>
                                                       </span>
                                </div>
                                <div id="collapse-8" class="collapse" aria-labelledby="heading-8"
                                     data-parent="#filterProduct">
                                    <div class="card-body">
                                        <?php
                                        if (!empty($count->attribute)) {
                                            foreach ($count->attribute as $value) {
                                                ?>
                                                <div class="checkbox">
                                                    <input class="form-check-input once-checkbox" type="checkbox"
                                                           name="<?php echo $value->name  ?>"
                                                           value="<?php echo $value->attribute  ?>"
                                                           id="filtertyp<?php echo $value->attribute  ?>">
                                                    <label for="filtertyp<?php echo $value->attribute  ?>">
                                                        <span class="check-span"></span>
                                                        <?php echo $value->attribute  ?>
                                                    </label>
                                                </div>
                                            <?php }
                                        } ?>
                                    </div>
                                </div>
                            </div>
                            <?php }
                            if ($access[10]->وزن == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                <div class="font-weight-bold card-header border-0 bg-transparent" id="heading-9"
                                     data-toggle="collapse" data-target="#collapse-9" aria-expanded="false"
                                     aria-controls="collapse-9">
                                                       <span class="align-items-center d-flex justify-content-between no-focus">
                                                            براساس وزن<i class="fa fa-plus"></i>
                                                       </span>
                                </div>
                                <div id="collapse-9" class="collapse" aria-labelledby="heading-9"
                                     data-parent="#filterProduct">
                                    <div class="card-body">
                                        <?php
                                        if (!empty($weight->attribute)) {
                                            foreach ($weight->attribute as $value) {
                                                ?>
                                                <div class="checkbox">
                                                    <input class="form-check-input once-checkbox" type="checkbox"
                                                           name="<?php echo $value->name  ?>"
                                                           value="<?php echo $value->attribute  ?>"
                                                           id="filtertypeE<?php echo $value->attribute  ?>">
                                                    <label for="filtertypeE<?php echo $value->attribute  ?>">
                                                        <span class="check-span"></span>
                                                        <?php echo $value->attribute  ?>
                                                    </label>
                                                </div>
                                            <?php }
                                        } ?>
                                    </div>
                                </div>
                            </div>
                            <?php }
                            if ($access[7]->درصدتخفیف == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                <div class="font-weight-bold card-header border-0 bg-transparent" id="heading-10"
                                     data-toggle="collapse" data-target="#collapse-10" aria-expanded="false"
                                     aria-controls="collapse-10">
                                                       <span class="align-items-center d-flex justify-content-between no-focus">
                                                            براساس درصد تخفیف<i class="fa fa-plus"></i>
                                                       </span>
                                </div>
                                <div id="collapse-10" class="collapse" aria-labelledby="heading-10"
                                     data-parent="#filterProduct">
                                    <div class="card-body">
                                        <?php
                                        if (!empty($offPercent->attribute)) {
                                            foreach ($offPercent->attribute as $value) {
                                                ?>
                                                <div class="checkbox">
                                                    <input class="form-check-input once-checkbox" type="checkbox"
                                                           name="<?php echo $value->name ?>"
                                                           value="<?php echo $value->attribute ?>"
                                                           id="filte<?php echo $value->attribute ?>">
                                                    <label for="filte<?php echo $value->attribute ?>">
                                                        <span class="check-span"></span>
                                                        <?php echo $value->attribute ?>
                                                    </label>
                                                </div>
                                            <?php }
                                        } ?>
                                    </div>
                                </div>
                            </div>
                            <?php }
                            if ($access[1]->رنگ == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                    <div class="font-weight-bold card-header border-0 bg-transparent" id="heading-11"
                                         data-toggle="collapse" data-target="#collapse-11" aria-expanded="false"
                                         aria-controls="collapse-11">
                                                       <span class="align-items-center d-flex justify-content-between no-focus">
                                                            براساس رنگ<i class="fa fa-plus"></i>
                                                       </span>
                                    </div>
                                    <div id="collapse-11" class="collapse" aria-labelledby="heading-11"
                                         data-parent="#filterProduct">
                                        <div class="card-body">
                                            <?php
                                            if (!empty($color->attribute)) {
                                                foreach ($color->attribute as $value) {
                                                    ?>
                                                    <div class="checkbox">
                                                        <input class="form-check-input once-checkbox" type="checkbox"
                                                               name="<?php echo $value->name ?>"
                                                               value="<?php echo $value->attribute ?>"
                                                               id="filtert<?php echo $value->attribute ?>">
                                                        <label for="filtert<?php echo $value->attribute ?>">
                                                            <span class="check-span"></span>
                                                            <?php echo $value->attribute ?>
                                                        </label>
                                                    </div>
                                                <?php }
                                            } ?>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            if ($access[2]->مدل == 1) { ?>
                                <div class="card border-0 mb-2 mb-md-4">
                                    <div class="font-weight-bold card-header border-0 bg-transparent" id="heading-12"
                                         data-toggle="collapse" data-target="#collapse-12" aria-expanded="false"
                                         aria-controls="collapse-12">
                                                       <span class="align-items-center d-flex justify-content-between no-focus">
                                                            براساس مدل<i class="fa fa-plus"></i>
                                                       </span>
                                    </div>
                                    <div id="collapse-12" class="collapse" aria-labelledby="heading-12"
                                         data-parent="#filterProduct">
                                        <div class="card-body">
                                            <?php
                                            if (!empty($model->attribute)) {
                                                foreach ($model->attribute as $value) {
                                                    ?>
                                                    <div class="checkbox">
                                                        <input class="form-check-input once-checkbox" type="checkbox"
                                                               name="<?php echo $value->name ?>"
                                                               value="<?php echo $value->attribute ?>"
                                                               id="filter<?php echo $value->attribute ?>">
                                                        <label for="filter<?php echo $value->attribute ?>">
                                                            <span class="check-span"></span>
                                                            <?php echo $value->attribute ?>
                                                        </label>
                                                    </div>
                                                <?php }
                                            } ?>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                        <input class="btn btn-block cta-btn" type="submit" name="filter" value="فیلتربندی">
                    </form>
                </div>
            </div>
            <div class="shop-product col-xl-9 col-md-8">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="page-title py-3 px-2">
                            <h2 class="text-center text-sm-right">محصولات جدید</h2>
                        </div>
                    </div>

                    <?php
                    if (!empty($product)) {
                        foreach ($product as $item) {
                            ?>

                            <div class="col-xl-4 col-sm-6 mb-3">
                                <a href="yield?id=<?php echo $item->id ?>"
                                   class="boxes float-top card border-0 text-dark nohover h-100">
                                    <div class="card-img-top">
                                        <img src="<?php echo $item->image[0]->image ?>">
                                    </div>
                                    <div class="card-body d-flex flex-column justify-content-end">
                                        <ul class="pis list-inline">
                                            <li class="mb-2">
                                                            <span class="font-weight-bold">نام:
                                                            </span><?php echo $item->name ?>
                                            </li>
                                            <li class="mb-2">
                                                            <span class="font-weight-bold">وزن:
                                                            </span><?php echo $item->weight ?>گرم
                                            </li>
                                            <li class="mb-2">
                                                            <span class="font-weight-bold">قیمت:
                                                            </span><?php echo number_format($item->price) ?>
                                                <span class="price-symbol">ریال</span>
                                            </li>
                                        </ul>
                                        <button class="btn rounded-pill cta-btn-primary d-block my-0 mx-auto px-5">بیشتر
                                        </button>
                                    </div>
                                </a>
                            </div>

                        <?php }
                    } ?>

                </div>
            </div>
        </div>
    </div>
</main>

<span id="jump-to-top" class="shadows jump-to-top-container tm-color">
               <i class="fa fa-chevron-up"></i>
          </span>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/js/swiper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.bundle.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/2.2.3/jquery.elevatezoom.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js'></script>
<link rel="stylesheet" href="http://mondas.ir/site/wholeTala/assets/css/style.css">
<?php
if (isset($_GET['login'])) {
    if ($_GET['login'] == "true") {
        echo "<script>swal('خوش آمدید!','ورود شما با موفقیت انجام شد', 'success');</script>";
    } elseif ($_GET['login'] == "false") {
        echo "<script>swal('متاسفیم', ' ورود با موفقیت انجام نشد', 'error');</script>";
    }
}

if (isset($_GET['logout'])) {
    echo "<script>swal(' باتشکر!','شما با موفقیت از حساب کاربری خود خارج شدید', 'success');</script>";
}

if (isset($_GET['add'])) {
    if ($_GET['add'] == "true") {
        echo "<script>swal(' باتشکر!','محصول شما به سبد خرید افزوده شد', 'success');</script>";
    } elseif ($_GET['add'] == "false") {
        echo "<script>swal('متاسفیم', 'محصول شما به سبدخرید اضافه نشد', 'error');</script>";
    }
}

?>

</body>
</html>

