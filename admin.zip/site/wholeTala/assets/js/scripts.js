$('a[href="#"]').on("click", function (e) {
    e.preventDefault();
});
//  (function () {
//      $openMobileMenu = $(".mobile-menu-open");
//      $closeMobileMenu = $(".mobile-menu-close");
//      $mobileMenu = $(".mobile-menu");

//      $openMobileMenu.click(function () {
//          $mobileMenu.addClass("menu-opened");
//      });
//      $closeMobileMenu.click(function () {
//          $mobileMenu.removeClass("menu-opened");
//      });
//  })();
$(".mobile-search-btn").click(function (e) {
    e.preventDefault(),
        $(".mobile-search").css("top", "0px"),
        $(".mobile-search .search-form input[type='search']").focus();
});
$(".close-search").click(function (e) {
    e.preventDefault(), $(".mobile-search").css("top", "-100px");
});
var widthWin = $(window).width();
$(window).scroll(function () {
    if (widthWin > 768) {
        if ($(window).scrollTop() > 180) {
            if ($(window).scrollTop() > 570) {
                $(".jump-to-top-container").addClass("show");
            } else {
                $(".jump-to-top-container").removeClass("show");
            }
        }
    }
});

$("#jump-to-top").on("click", function (e) {
    e.preventDefault(), $("html,body").animate({ scrollTop: 0 }, 500);
});

var swiperHomeSlider = new Swiper(".home-slider", {
    navigation: {
        nextEl: ".home-slider-button-next",
        prevEl: ".home-slider-button-prev",
    },
    pagination: {
        el: ".home-slider-pagination",
    },
    autoplay: {
        delay: 5000,
    },
    speed: 300,
    effect: "fade",
    fadeEffect: {
        crossFade: true,
    },
    loop: true,
});
var productSwiper = new Swiper(".product-swiper-container", {
    spaceBetween: 10,
    navigation: {
        nextEl: ".product-slider-button-next",
        prevEl: ".product-slider-button-prev",
    },
    breakpoints: {
        0: {
            slidesPerView: 2,
        },
        576: {
            slidesPerView: 3,
        },
    },
});

// (function () {
//     const breakpoint = window.matchMedia("(max-width:768px)");

//     const breakpointChecker = function () {
//         // if larger viewport and multi-row layout needed
//         if (breakpoint.matches === true) {
//             // clean up old instances and inline styles when available


//             // or/and do nothing
//             return;

//             // else if a small viewport and single column layout needed
//         } else if (breakpoint.matches === false) {
//             // fire small viewport version of swiper
//             return disableZoom();
//         }
//     };
//     const disableZoom = function () {
//         $("#product-image").elevateZoom({
//             // zoomType: "inner",
//             gallery: "product-gallery",
//             // cursor: "crosshair",
//             // galleryActiveClass: "active",
//             imageCrossfade: true,
//             zoomWindowPosition: 11,
//             easing: true,
//             // zoomWindowOffetx: 10,
//         });
//     }
//     // keep an eye on viewport size changes
//     breakpoint.addListener(breakpointChecker);

//     // kickstart
//     breakpointChecker();
// })();
$("#product-image").elevateZoom({
    // zoomType: "inner",
    gallery: "product-gallery",
    // cursor: "crosshair",
    // galleryActiveClass: "active",
    imageCrossfade: true,
    zoomWindowPosition: 11,
    easing: true,
    // zoomWindowOffetx: 10,
});
//pass the images to Fancybox
$("#product-image").bind("click", function (e) {
    var ez = $("#product-image").data("elevateZoom");
    $.fancybox(ez.getGalleryList());
    return false;
});

$("input.once-checkbox:checkbox").on("click", function () {
    var $box = $(this);
    if ($box.is(":checked")) {
        var group = "input:checkbox[name='" + $box.attr("name") + "']";
        $(group).prop("checked", false);
        $box.prop("checked", true);
    } else {
        $box.prop("checked", false);
    }
});

$("#priceControlRange")
    .on("input", function () {
        $("#priceControlRange + .output").val(this.value + "0,000,000  ریال");
    })
    .trigger("change");
$("#weightControlRange")
    .on("input", function () {
        $("#weightControlRange + .output").val(this.value + " گرم");
    })
    .trigger("change");