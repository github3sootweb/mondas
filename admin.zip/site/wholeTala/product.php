<?php
include_once "../controller/controller.php";
if (isset($_GET['id'])) {
    $product = getProductByIds($_GET['id']);

    if (!isset($_COOKIE['cart'])) {
        addWholeCart($_GET['id']);
    } else {
        addProductToWholeCart($_GET['id']);
    }

    addWholeLetMeKnow($_GET['id']);

    addWholeComment($_GET['id']);
}
signInWholeSaler();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>محصول</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/css/swiper.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://mondas.ir/site/wholeTala/assets/css/style.css">
</head>

<body>
<header id="Site-Header">
    <div class="header-top container-xl py-1">
        <div class="row">
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-sign d-flex align-items-center h-100">
                    <?php if (isset($_COOKIE['name'])) : ?>
                        <button class="sign-btn btn cta-btn rounded-pill" data-toggle="modal"
                                data-target="#logoutmodal">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo $_COOKIE['name']; ?>
                                </span>
                        </button>
                        <!-- Modal: Logout Start -->
                        <div class="modal fade" id="logoutmodal" tabindex="-1" aria-labelledby="logoutmodalLabel"
                             aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">خروج از حساب کاربری</h5>
                                    </div>
                                    <div class="modal-body">
                                        <p class="mb-0">خارج می‌شوید؟</p>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">ادامه
                                            در سایت
                                        </button>
                                        <a href="logout" class="btn btn-danger">خروج</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Logout End -->
                    <?php else : ?>
                        <button class="sign-btn btn cta-btn rounded-pill" data-toggle="modal"
                                data-target="#modalLRForm">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo "ورود"; ?>
                                </span>
                        </button>
                        <!-- Modal: Login / Register Start -->
                        <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog"
                             aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#login-tab" role="tab">
                                                <i class="fas fa-user ml-1"></i>ورود</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <!--- login --->
                                        <div class="tab-pane fade in show active" id="login-tab" role="tabpanel">
                                            <div class="modal-body mb-1">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" name="username"
                                                               id="email-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-login">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password"
                                                               id="password-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-login">رمز عبور</label>
                                                    </div>

                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signIn"
                                                                type="submit">ورود
                                                            <i class="fas fa-user ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="options text-center text-md-right mt-1">
                                                </div>
                                                <button type="button" class="btn btn-outline-danger mr-auto"
                                                        data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Login / Register End -->
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6 col-md-4 col-6">
                <div class="logo d-flex align-items-center justify-content-center h-100">
                    <a href="whole" class="d-block"><img src="http://mondas.ir/site/wholeTala/assets/images/logo.png"></a>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-search d-flex align-items-center justify-content-end h-100">
                    <form class="search-form position-relative d-none d-md-block w-100" method="GET"
                          action="whole?search=<?php echo $_GET['search'] ?>">
                        <input class="form-control rounded-pill" type="search" name="search" placeholder="جستجو..."
                               aria-label="Search">
                        <button class="btn position-absolute" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>
                    <div class="w-100 text-left d-block d-md-none">
                        <button class="btn cta-btn mobile-search-btn rounded-pill">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="mobile-search position-absolute w-100 py-4 bg-white">
                <div class="container">
                    <div class="row">
                        <span class="close-search tm-color col-2">بستن</span>
                        <div class="col-10">
                            <form class="search-form position-relative d-block d-md-none w-100" method="GET"
                                  action="whole?search=<?php echo $_GET['search'] ?>">
                                <input class="form-control" type="search" name="search" placeholder="جستجو..."
                                       aria-label="Search">
                                <button class="btn position-absolute" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom container-xl py-2">
        <div class="row">
            <div class="col-sm-3 col-6 header-nav-icons">
                <a href="whole">
                    <i class="fa fa-home ml-3"></i>
                </a>
                <a href="hamper">
                    <i class="fa fa-shopping-cart"></i>
                </a>
            </div>
            <?php if (isset($_COOKIE['amount'])) { ?>
                <div class="col-sm-9 col-6">
                    <div class="header-sign d-flex align-items-center justify-content-end h-100">
                        <a href="#" class="cta-btn btn rounded-pill">موجودی <?php echo $_COOKIE['amount']  ?> ریال</a>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>
    <!--Modal: Login / Register Form-->
    <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#login-tab" role="tab">
                            <i class="fas fa-user ml-1"></i>ورود</a>
                    </li>
                </ul>
                <div
                        class="tab-content">
                    <!--- login --->
                    <div class="tab-pane fade in show active" id="login-tab" role="tabpanel">
                        <form method="post">
                            <div class="modal-body mb-1">
                                <div class="form-group has-float-label">
                                    <input type="text" placeholder="&nbsp;" name="username" id="email-login"
                                           class="form-control">
                                    <span class="form-bar"></span>
                                    <label class="float-label" for="email-login">نام کاربری</label>
                                </div>
                                <div class="form-group has-float-label">
                                    <input type="password" placeholder="&nbsp;" name="password" id="password-login"
                                           class="form-control">
                                    <span class="form-bar"></span>
                                    <label class="float-label" for="password-login">رمز عبور</label>
                                </div>

                                <div class="text-center mt-2">
                                    <button class="btn btn-block cta-btn" name="signIn" type="submit">ورود
                                        <i class="fas fa-user ml-1"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <div class="options text-center text-md-right mt-1"></div>
                                <button type="button" class="btn btn-outline-danger mr-auto" data-dismiss="modal">بستن
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Modal: Login / Register Form-->
</header>

<main>
    <div id="Site-Wrapper" class="container-xl">
        <section class="single-product-preview py-3 py-md-4">
            <div class="single-product-preview-inner row no-gutters rounded shadows bg-white">
                <div class="col-sm-6 pl-md-3 pl-sm-2 pl-0 mb-3 mb-sm-0">
                    <div class="row no-gutters">
                        <div class="product-image-wrap p-lg-5 p-md-3 p-sm-2 p-2 w-100">
                            <div class="product-image-container">
                                <div class="product-image-wrapper ">
                                    <img id="product-image" src="<?php echo $product->image[0]->image ?>"
                                         data-zoom-image="<?php echo $product->image[0]->image ?>" class="img-fluid"/>
                                </div>
                                <div class="swiper-container product-swiper-container py-2 px-1">
                                    <div id="product-gallery" class="swiper-wrapper">
                                        <?php
                                        if (!empty($product->image)) {
                                            foreach ($product->image as $value) {
                                                ?>
                                                <a href="#" data-image="<?php echo $value->image ?>"
                                                   data-zoom-image="<?php echo $value->image ?>"
                                                   class="swiper-slide box-rounded">
                                                    <img src="<?php echo $value->image ?>" class="img-fluid">
                                                </a>
                                            <?php }
                                        } ?>
                                    </div>
                                    <div class="product-slider-button-next swiper-button-next"></div>
                                    <div class="product-slider-button-prev swiper-button-prev"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 pr-md-3 pr-sm-2 pr-0">
                    <div class="row no-gutters h-100">
                        <div class="product-sale-details p-lg-5 p-md-3 p-sm-2 p-4 w-100">
                            <div class="product-sale-container box-rounded inner-wrapper mb-3">
                                <p class="small">
                                                       <span class="font-weight-bold">دسته بندی:
                                                       </span><?php echo $product->category ?>
                                </p>
                                <h1 class="product-title"><?php echo $product->name ?></h1>
                                <p class="py-2 mb-0 border-bottom">
                                                       <span>مدل:
                                                       </span><?php echo $product->model ?>
                                </p>
                                <p class="py-2 mb-0 border-bottom">
                                                       <span>وزن:
                                                       </span><?php echo $product->weight ?>گرم
                                </p>
                                <p class="product-price">
                                                       <span class="price-amount">
                                                            <bdi><?php echo number_format($product->price) ?><span
                                                                        class="price-symbol">&nbsp;ریال</span>
                                                            </bdi>
                                                       </span>
                                </p>
                            </div>

                            <?php
                            if (!empty($_COOKIE['id'])) {
                                if ($product->count == 0) { ?>

                                    <div class="add-to-cart-container text-center  text-md-left">
                                        <button class="add-to-cart btn btn-lg btn-secondary text-white rounded-pill"
                                                data-toggle="modal" data-target="#productfinished">اطلاع رسانی اتمام
                                            محصول <i class="fa fa-info"></i></button>
                                    </div>
                                    <!-- Modal: Product Finished Start -->
                                    <div class="modal fade" id="productfinished" tabindex="-1"
                                         aria-labelledby="productfinishedLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">اطلاع رسانی اتمام محصول</h5>
                                                </div>
                                                <div class="modal-body mb-1">
                                                    <form method="post">
                                                        <div class="form-group has-float-label">
                                                            <textarea placeholder="&nbsp;" name="message"
                                                                      id="info-message" class="form-control border-0"
                                                                      rows="5" required></textarea>
                                                            <span class="form-bar"></span>
                                                            <label class="float-label" for="info-message">پیام اطلاع
                                                                رسانی</label>
                                                        </div>
                                                        <div class="text-center mt-2">
                                                            <button class="btn btn-block cta-btn" name="sendInfo"
                                                                    type="submit">ارسال پیام
                                                                <i class="fas fa-info ml-1"></i>
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-outline-danger"
                                                            data-dismiss="modal">بستن
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal: Product Finished End -->

                                <?php } else { ?>

                                    <div class="add-to-cart-container text-center text-md-left">
                                        <form method="post">
                                            <button type="submit" name="add"
                                                    class="add-to-cart btn btn-lg cta-btn rounded-pill">افزودن به سبد
                                                خرید <i class="fa fa-shopping-cart"></i></button>
                                        </form>
                                    </div>

                                <?php }
                            } else { ?>

                                <div class="add-to-cart-container text-center text-md-left">
                                    <button type="submit" name="add" class="add-to-cart btn btn-lg cta-btn rounded-pill"
                                            data-toggle="modal" data-target="#modalLRForm">ابتدا وارد حساب کاربری خود
                                        شوید <i class="fa fa-user"></i></button>
                                </div>

                            <?php } ?>


                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="single-product-details py-3 py-md-4">
            <div class="product-details-wrapper rounded bg-white shadows m-auto">
                <ul class="nav pis rounded bg-white shadows" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link nohover active" id="product-details-description-tab" data-toggle="pill"
                           href="#product-details-description" role="tab" aria-controls="product-details-description"
                           aria-selected="true">جزئیات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nohover" id="product-description-tab" data-toggle="pill"
                           href="#product-description" role="tab" aria-controls="product-description"
                           aria-selected="false">توضیحات تکمیلی</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nohover" id="product-comments-tab" data-toggle="pill"
                           href="#product-comments" role="tab" aria-controls="product-comments" aria-selected="false">نظرات</a>
                    </li>
                </ul>
                <div class="tab-content inner-wrapper" id="tabContent">
                    <div class="tab-pane fade show active" id="product-details-description" role="tabpanel"
                         aria-labelledby="product-details-description-tab">
                        <table class="table table-borderless">
                            <tbody>
                            <tr>
                                <td>وزن</td>
                                <td><?php echo $product->weight ?> گرم</td>
                            </tr>
                            <tr>
                                <td>جنسیت</td>
                                <td><?php
                                    if ($product->gender == "men") {
                                        echo "مردانه";
                                    } elseif ($product->gender == "women") {
                                        echo "زنانه";
                                    } elseif ($product->gender == "both") {
                                        echo "هردو";
                                    }
                                    ?></td>
                            </tr>
                            <tr>
                                <td>عیار</td>
                                <td> عیار<?php echo $product->gold_carat ?></td>
                            </tr>
                            <tr>
                                <td>کالکشن</td>
                                <td><?php echo $product->colaction ?></td>
                            </tr>
                            <tr>
                                <td>رنگ</td>
                                <td><?php echo $product->color ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="product-description" role="tabpanel"
                         aria-labelledby="product-description-tab">
                        <div class="decription-text p-3">
                            <p><?php echo $product->description ?></p>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="product-comments" role="tabpanel"
                         aria-labelledby="product-comments-tab">
                        <div class="container-fluid inner-wrapper">
                            <div class="row no-gutters">
                                <?php
                                if (!empty($product->comment)) {
                                    foreach ($product->comment as $value) {
                                        ?>
                                        <div class="col-12">
                                            <div class="d-sm-flex mb-4">
                                                <img class="d-flex comment-avatar rounded-circle mt-sm-3 mb-sm-0 mb-3 ml-2"
                                                     src="http://mondas.ir/site/wholeTala/assets/images/man.svg">
                                                <div class="comment-body w-100 shadows bg-light p-3 p-md-5">
                                                    <div class="mb-2">
                                                        <h5 class="mb-0"><?php echo $value->user_name ?></h5>
                                                    </div>
                                                    <p><?php echo $value->comment ?></p>
                                                </div>
                                            </div>
                                        </div>

                                    <?php }
                                }
                                if (isset($_COOKIE['id'])) {
                                    ?>
                                    <div class="col-12">
                                        <div class="send-comment-wrapper bg-white rounded py-3 px-3 px-sm-4">
                                            <form method="post">
                                                <div class="form-group has-float-label mt-0">
                                                    <textarea placeholder="&nbsp;" name="comment" id="comment-message"
                                                              class="form-control border-0 p-3" rows="5"></textarea>
                                                    <span class="form-bar"></span>
                                                    <label class="float-label p-2" for="comment-message">دیدگاه
                                                        شما</label>
                                                </div>
                                                <div class="mt-2">
                                                    <button class="btn cta-btn" name="sendComment" type="submit">ارسال
                                                        <i class="fas fa-comment-dots ml-1"></i>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</main>

<span id="jump-to-top" class="shadows jump-to-top-container tm-color">
               <i class="fa fa-chevron-up"></i>
          </span>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/js/swiper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.bundle.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/2.2.3/jquery.elevatezoom.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js'></script>
<script src="http://mondas.ir/site/wholeTala/assets/js/scripts.js"></script>


<?php
if (isset($_GET['comment'])) {
    if ($_GET['comment'] == "true") {
        echo "<script>swal(' باتشکر!','نظر شما با موفقیت ثبت گردید', 'success');</script>";
    } elseif ($_GET['comment'] == "false") {
        echo "<script>swal('متاسفیم', 'نظر شما با موفقیت ثبت نشد', 'error');</script>";
    }
}

if (isset($_GET['know'])) {
    if ($_GET['know'] == "true") {
        echo "<script>swal(' باتشکر!','محصول به زودی در دسترس قرار خواهد گرفت', 'success');</script>";
    } elseif ($_GET['know'] == "false") {
        echo "<script>swal('متاسفیم', 'پیغام شما ثبت نگردید', 'error');</script>";
    }
}
?>
</body>

</html>
