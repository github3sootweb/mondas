<?php
include_once "../controller/controller.php";
if (isset($_COOKIE['cart'])) {
    $all = getWholeCart($_COOKIE['cart']);

    if (!empty($all[0])) {
        $product = $all[0];

    }

    if (!empty($all[1])) {
        $total = $all[1];
    } else {
        $total = 0;
    }


    if (isset($_GET['opt'])) {
        deletePurchaseProduct($_GET['opt']);
    }
}else{
    $total = 0;
}
signInWholeSaler();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سبد خرید</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/css/swiper.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://mondas.ir/site/wholeTala/assets/css/style.css">
</head>

<body>
<header id="Site-Header">
    <div class="header-top container-xl py-1">
        <div class="row">
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-sign d-flex align-items-center h-100">
                    <?php if (isset($_COOKIE['name'])) : ?>
                        <button class="sign-btn btn cta-btn rounded-pill" data-toggle="modal"
                                data-target="#logoutmodal">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo $_COOKIE['name']; ?>
                                </span>
                        </button>
                        <!-- Modal: Logout Start -->
                        <div class="modal fade" id="logoutmodal" tabindex="-1" aria-labelledby="logoutmodalLabel"
                             aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">خروج از حساب کاربری</h5>
                                    </div>
                                    <div class="modal-body">
                                        <p class="mb-0">خارج می‌شوید؟</p>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">ادامه
                                            در سایت
                                        </button>
                                        <a href="logout" class="btn btn-danger">خروج</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Logout End -->
                    <?php else : ?>
                        <button class="sign-btn btn cta-btn rounded-pill" data-toggle="modal"
                                data-target="#modalLRForm">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo "ورود"; ?>
                                </span>
                        </button>
                        <!-- Modal: Login / Register Start -->
                        <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog"
                             aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#login-tab" role="tab">
                                                <i class="fas fa-user ml-1"></i>ورود</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <!--- login --->
                                        <div class="tab-pane fade in show active" id="login-tab" role="tabpanel">
                                            <div class="modal-body mb-1">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" name="username"
                                                               id="email-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-login">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password"
                                                               id="password-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-login">رمز عبور</label>
                                                    </div>

                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signIn"
                                                                type="submit">ورود
                                                            <i class="fas fa-user ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="options text-center text-md-right mt-1">
                                                </div>
                                                <button type="button" class="btn btn-outline-danger mr-auto"
                                                        data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Login / Register End -->
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6 col-md-4 col-6">
                <div class="logo d-flex align-items-center justify-content-center h-100">
                    <a href="whole" class="d-block"><img src="http://mondas.ir/site/wholeTala/assets/images/logo.png"></a>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-search d-flex align-items-center justify-content-end h-100">
                    <form class="search-form position-relative d-none d-md-block w-100" method="GET"
                          action="whole?search=<?php echo $_GET['search'] ?>">
                        <input class="form-control rounded-pill" type="search" name="search" placeholder="جستجو..."
                               aria-label="Search">
                        <button class="btn position-absolute" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>
                    <div class="w-100 text-left d-block d-md-none">
                        <button class="btn cta-btn mobile-search-btn rounded-pill">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="mobile-search position-absolute w-100 py-4 bg-white">
                <div class="container">
                    <div class="row">
                        <span class="close-search tm-color col-2">بستن</span>
                        <div class="col-10">
                            <form class="search-form position-relative d-block d-md-none w-100" method="GET"
                                  action="whole?search=<?php echo $_GET['search'] ?>">
                                <input class="form-control" type="search" name="search" placeholder="جستجو..."
                                       aria-label="Search">
                                <button class="btn position-absolute" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom container-xl py-2">
        <div class="row">
            <div class="col-sm-3 col-6 header-nav-icons">
                <a href="whole">
                    <i class="fa fa-home ml-3"></i>
                </a>
                <a href="hamper">
                    <i class="fa fa-shopping-cart"></i>
                </a>
            </div>
            <?php if (isset($_COOKIE['amount'])) { ?>
                <div class="col-sm-9 col-6">
                    <div class="header-sign d-flex align-items-center justify-content-end h-100">
                        <a href="#" class="cta-btn btn rounded-pill">موجودی <?php echo $_COOKIE['amount'] ?> ریال</a>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>

</header>

<main>
    <div id="Site-Wrapper" class="container-xl">
        <section class="cart row py-3 py-md-5">
            <div class="col-lg-8">
                <div class="cart-table p-3 p-lg-0">
                    <table class="table w-100">
                        <thead>
                        <tr>
                            <th>&nbsp;</th>
                            <th>تصویر</th>
                            <th>محصول</th>
                            <th>قیمت</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if (!empty($product)) {
                            foreach ($product as $item) {
                                ?>
                                <tr>
                                    <td class="product-remove">
                                        <a href="hamper?opt=<?php echo $item->PurchaseProduct_id ?>"
                                           class="remove">×</a>
                                    </td>
                                    <td class="product-thumbnail">
                                        <a href="<?php echo $item->image[0]->image ?>"><img
                                                    src="<?php echo $item->image[0]->image ?>" class="img-fluid"></a>
                                    </td>
                                    <td class="product-name">
                                        <a href=""><?php echo $item->product_name ?></a>
                                    </td>
                                    <td class="product-price" data-title="قیمت"><?php echo number_format($item->price) ?><span>&nbsp;ریال</span>
                                    </td>
                                </tr>
                            <?php }
                        } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-4 pb-5">
                <div class="row">
                    <div class="col-md-12">
                        <div class="cart-total card mb-3">
                            <div class="card-header text-dark">
                                مجموع سبد خرید
                            </div>
                            <div class="card-body p-0">
                                <ul class="list-group list-group-flush pis">
                                    <li class="list-group-item d-flex justify-content-between">مبلغ کل: <span
                                                class="font-weight-bold"></span><?php echo number_format($total) ?>
                                        <span>&nbsp;ریال</span></span></li>
                                </ul>

                            </div>
                            <div class="card-footer">
                                <a href="#" class="btn cta-btn btn-block my-1">تایید نهایی و پرداخت<i
                                            class="fa fa-chevron-left mr-1"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 mb-3 mb-md-0">
                        <div class="accordion cart-accordion" id="coupon">
                            <div class="card">
                                <div class="card-header p-0" id="couponDetailHead">
                                    <h2 class="mb-0">
                                        <button class="btn btn-block text-dark text-right p-2 collapsed" type="button"
                                                data-toggle="collapse" data-target="#coupon-details"
                                                aria-expanded="false" aria-controls="coupon-details">
                                            توضیحات
                                            <i class="fa fa-chevron-down"></i></button>
                                    </h2>
                                </div>
                                <div id="coupon-details" class="collapse" aria-labelledby="couponDetailHead"
                                     data-parent="#coupon">
                                    <div class="card-body">
                                        <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از
                                            طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که
                                            لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف
                                            بهبود ابزارهای کاربردی می باشد، کتابهای زیادی در شصت و سه درصد گذشته حال و
                                            آینده، شناخت فراوان جامعه و متخصصان را می طلبد، تا با نرم افزارها شناخت
                                            بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی، و فرهنگ پیشرو در
                                            زبان فارسی ایجاد کرد، در این صورت می توان امید داشت که تمام و دشواری موجود
                                            در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و زمان مورد نیاز شامل
                                            حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی
                                            اساسا مورد استفاده قرار گیرد.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</main>


<span id="jump-to-top" class="shadows jump-to-top-container tm-color">
          <i class="fa fa-chevron-up"></i>
     </span>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/js/swiper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.bundle.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/2.2.3/jquery.elevatezoom.min.js'></script>
<script src="http://mondas.ir/site/wholeTala/assets/js/scripts.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
if (isset($_GET['delete'])) {
    if ($_GET['delete'] == "true") {
        echo "<script>swal(' موفقیت آمیز!','محصول شما از سبد خرید حذف شد', 'success');</script>";
    } elseif ($_GET['delete'] == "false") {
        echo "<script>swal('متاسفیم', 'محصول شما از سبد خرید حذف نشد', 'error');</script>";
    }
}
?>
</body>

</html>