<?php

$url = "http://mondas.ir:4000";


function signUp(){
    if(isset($_POST['signUp'])){
        global $url;
        $username = $_POST['username'];
        $fullName = $_POST['fullName'];
        $password = $_POST['password'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/AddUsers",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => "$username",'password' => "$password",'user_full_name' => "$fullName",'address' => "$address",'phone' => "$phone",'email' => "$email"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'home?signUp=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'home?signUp=false'; </script>";
        }
    }
}

function signIn(){
    if(isset($_POST['signIn'])){
        global $url;
        $username = $_POST['username'];
        $password = $_POST['password'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/Login2",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => "$username",'password' => "$password"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            setcookie('id', $info->id, time() + 5 * 24 * 60 * 60);
            setcookie('name', $info->name, time() + 5 * 24 * 60 * 60);
            // echo "<script type='text/javascript'> document.cookie = 'id=$show->id';</script>";
            echo "<script type='text/javascript'> document.location = 'home?login=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'home?login=false'; </script>";
            
        }
    }
}

function getDataById($value, $item)
{
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/$item",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data[0];
    } else {

    }
}

function getData($value)
{
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/$value",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addUser(){
    if(isset($_POST['add'])){
        global $url;
        $username = $_POST['username'];
        $fullName = $_POST['fullName'];
        $password = $_POST['password'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $amount = $_POST['amount'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/AddUsers",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => "$username",'password' => "$password",'user_full_name' => "$fullName",'address' => "$address",'phone' => "$phone",'email' => "$email",'amount' => "$amount"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'home?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'home?add=false'; </script>";
        }
    }
}

function getSliders($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/SearchSlider",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array("$value" => 'get'),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function bestGolds(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/sellGolde",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function bestSilvers(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/sellsilver",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getFirstProducts($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/first",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('is_gold' => "$value"),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getLastProducts($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/last",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('is_gold' => "$value"),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getSilverCollections(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/consilver",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getGoldCollections(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/congold",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getProductsByCategory($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProducts",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('category' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getAllProducts(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProducts",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getProductsByCollection($value){
    global $url;
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProducts",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('colaction' => "$value"),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function filterData(){
    if(isset($_POST['filter'])){
        global $url;
        $z = array();
        if(!empty($_POST['range'])){
            $range = $_POST['range'];
            $mainRange = $range . '0000000';
        }else{
            $mainRange = '';
        }
        array_push($z, ['range' => $mainRange]);

        if (!empty($_POST['gender'])) {
            $gender = $_POST['gender'];
        } else {
            $gender = "";
        }
        array_push($z, ['gender' => $gender]);

        if (!empty($_POST['count'])) {
            $count = $_POST['count'];
        } else {
            $count = "";
        }
        array_push($z, ['count' => $count]);

        if (!empty($_POST['weight'])) {
            $weight = $_POST['weight'];
        } else {
            $weight = "";
        }
        array_push($z, ['weight' => $weight]);

        if (!empty($_POST['offPercent'])) {
            $offPercent = $_POST['offPercent'];
        } else {
            $offPercent = "";
        }
        array_push($z, ['offPercent' => $offPercent]);

        if (!empty($_POST['color'])) {
            $color = $_POST['color'];
        } else {
            $color = "";
        }
        array_push($z, ['color' => $color]);

        if (!empty($_POST['model'])) {
            $model = $_POST['model'];
        } else {
            $model = "";
        }
        array_push($z, ['model' => $model]);

        if (!empty($_POST['carat'])) {
            $carat = $_POST['carat'];
        } else {
            $carat = "";
        }
        array_push($z, ['carat' => $carat]);

        if (!empty($_POST['off'])) {
            $off = $_POST['off'];
        } else {
            $off = "";
        }
        array_push($z, ['off' => $off]);



        if (!empty($_POST['gens'])) {
            $gens = $_POST['gens'];
        } else {
            $gens = "";
        }
        array_push($z, ['gens' => $gens]);

        if (!empty($_POST['category'])) {
            $category = $_POST['category'];
            $x = count($category);
            $b = [];
            for ($i = 0; $i < $x; $i++) {
                array_push($b, $category[$i]);
            }
            array_push($z, ['category' => $b]);
        } else {
            $category = [];
            array_push($z, ['category' => $category]);
        }

        if (!empty($_POST['collection'])) {
            $collection = $_POST['collection'];
            $x = count($collection);
            $b = [];
            for ($i = 0; $i < $x; $i++) {
                array_push($b, $collection[$i]);
            }
            array_push($z, ['collection' => $b]);
        } else {
            $collection = [];
            array_push($z, ['collection' => $collection]);
        }

        $y = json_encode($z);
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/filters",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>$y,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $res = json_decode($response);
        if (!empty($res->data)) {
            return $res->data;
        } else {

        }
    }
}

function getCategories(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetCategories",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getRandomData(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/rand",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getProductsBySearch($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/Search",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('search' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function addLetMeKnow($value){
    if(isset($_POST['sendInfo'])){
        global $url;
        $message =$_POST['message'];
        $cookie = $_COOKIE['id'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddLetMyKnow",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('product' => "$value",'user' => "$cookie",'massage' => "$message"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'commodity?know=true&id=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'commodity?know=false&id=$value'; </script>";
        }
    }
}

function addCart($value){
    if(isset($_POST['add'])){
        global $url;
        $cookie = $_COOKIE['id'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddCart",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('user' => "$cookie",'product' => "$value"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            setcookie('cart', $info->id, time() + 3600);
            echo "<script type='text/javascript'> document.location = 'shop?all&add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'shop?all&add=false'; </script>";
        }
    }
}

function addProductTocart($value){
    if(isset($_POST['add'])) {
        $cookie = $_COOKIE['cart'];
        global $url;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddPurchaseProduct",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('product' => "$value", 'cart' => "$cookie"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'shop?all&add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'shop?all&add=false'; </script>";
        }
    }
}

function getCart(){
    $cookie = $_COOKIE['cart'];
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetCart",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$cookie"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        $all = [$info->data , $info->total];
        return $all;
    } else {

    }
}

function deletePurchaseProduct($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/DeletePurchaseProduct",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if ($info->success == true) {
        echo "<script type='text/javascript'> document.location = 'cart?delete=true'; </script>";
    } else {
        echo "<script type='text/javascript'> document.location = 'cart?delete=false'; </script>";
    }
}

function addComment($value){
    if(isset($_POST['sendComment'])){
        global $url;
        $comment =$_POST['comment'];
        $cookie = $_COOKIE['id'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddProductComment",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('product' => "$value",'user' => "$cookie",'comment' => "$comment" , 'vote'=>0),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'commodity?comment=true&id=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'commodity?comment=false&id=$value'; </script>";
        }
    }
}

function getAbout(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/users/GetAbout",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data[0];
    } else {

    }
}

function addEmail(){
    if(isset($_POST['add'])){
        global $url;
        $email = $_POST['email'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddEmail",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('email' => "$email"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = ?email=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'home?email=false'; </script>";
        }
    }
}


function getCollactions(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetColactions",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function getAccess(){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetAccess",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->access)) {
        $all = [$info->data , $info->access];
        return $all;

    } else {

    }
}






function getProductByUserId()
{
    global $url;
    $cookie = $_COOKIE['id'];
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProducts",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('user_id' => "$cookie"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}

function signInWholeSaler()
{
    if (isset($_POST['signIn'])) {
        global $url;
        $username = $_POST['username'];
        $password = $_POST['password'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/users/Login3",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => "$username", 'password' => "$password"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            setcookie('id', $info->id, time() + 5 * 24 * 60 * 60);
            setcookie('name', $info->name, time() + 5 * 24 * 60 * 60);
            setcookie('amount', $info->amount, time() + 5 * 24 * 60 * 60);
            echo "<script type='text/javascript'> document.location = 'whole'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'whole?login=false'; </script>";
        }
    }
}

function getProductByIds($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetProducts",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('ids' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data[0];
    } else {

    }
}

function searchProductByUserId($value){
    global $url;
    $cookie = $_COOKIE['id'];
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/searchOmde",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('user_id' => "$cookie",'search' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        return $info->data;
    } else {

    }
}


function addWholeCart($value)
{
    if (isset($_POST['add'])) {
        global $url;
        $cookie = $_COOKIE['id'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddCart",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('user' => "$cookie", 'product' => "$value"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            setcookie('cart', $info->id, time() + 3600);
            echo "<script type='text/javascript'> document.location = 'whole?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'whole?add=false'; </script>";
        }
    }
}

function addProductToWholeCart($value)
{
    if (isset($_POST['add'])) {
        $cookie = $_COOKIE['cart'];
        global $url;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddPurchaseProduct",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('product' => "$value", 'cart' => "$cookie"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'whole?add=true'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'whole?add=false'; </script>";
        }
    }
}


function getWholeCart($value){
    global $url;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "$url/products/GetCartOmde",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('id' => "$value"),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $info = json_decode($response);
    if (!empty($info->data)) {
        $all = [$info->data , $info->total];
        return $all;

    } else {

    }
}


function filterWholeData(){
    if(isset($_POST['filter'])){
        global $url;
        $cookie = $_COOKIE['id'];
        $z = array();
        if(!empty($_POST['range'])){
            $range = $_POST['range'];
            $mainRange = $range . '0000000';
        }else{
            $mainRange = '';
        }
        array_push($z, ['range' => $mainRange]);

        if (!empty($_POST['gender'])) {
            $gender = $_POST['gender'];
        } else {
            $gender = "";
        }
        array_push($z, ['gender' => $gender]);

        if (!empty($_POST['count'])) {
            $count = $_POST['count'];
        } else {
            $count = "";
        }
        array_push($z, ['count' => $count]);

        if (!empty($_POST['weight'])) {
            $weight = $_POST['weight'];
        } else {
            $weight = "";
        }
        array_push($z, ['weight' => $weight]);

        if (!empty($_POST['offPercent'])) {
            $offPercent = $_POST['offPercent'];
        } else {
            $offPercent = "";
        }
        array_push($z, ['offPercent' => $offPercent]);

        if (!empty($_POST['color'])) {
            $color = $_POST['color'];
        } else {
            $color = "";
        }
        array_push($z, ['color' => $color]);

        if (!empty($_POST['model'])) {
            $model = $_POST['model'];
        } else {
            $model = "";
        }
        array_push($z, ['model' => $model]);

        if (!empty($_POST['carat'])) {
            $carat = $_POST['carat'];
        } else {
            $carat = "";
        }
        array_push($z, ['carat' => $carat]);

        if (!empty($_POST['off'])) {
            $off = $_POST['off'];
        } else {
            $off = "";
        }
        array_push($z, ['off' => $off]);



        if (!empty($_POST['gens'])) {
            $gens = $_POST['gens'];
        } else {
            $gens = "";
        }
        array_push($z, ['gens' => $gens]);

        if (!empty($_POST['category'])) {
            $category = $_POST['category'];
            $x = count($category);
            $b = [];
            for ($i = 0; $i < $x; $i++) {
                array_push($b, $category[$i]);
            }
            array_push($z, ['category' => $b]);
        } else {
            $category = [];
            array_push($z, ['category' => $category]);
        }

        if (!empty($_POST['collection'])) {
            $collection = $_POST['collection'];
            $x = count($collection);
            $b = [];
            for ($i = 0; $i < $x; $i++) {
                array_push($b, $collection[$i]);
            }
            array_push($z, ['collection' => $b]);
        } else {
            $collection = [];
            array_push($z, ['collection' => $collection]);
        }
        array_push($z, ['user' => $cookie]);
        $y = json_encode($z);
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/filtersOmde",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>$y,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $res = json_decode($response);
        if (!empty($res->data)) {
            return $res->data;
        } else {

        }
    }
}

function addWholeLetMeKnow($value){
    if(isset($_POST['sendInfo'])){
        global $url;
        $message =$_POST['message'];
        $cookie = $_COOKIE['id'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddLetMyKnow",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('product' => "$value",'user' => "$cookie",'massage' => "$message"),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'yield?know=true&id=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'yield?know=false&id=$value'; </script>";
        }
    }
}

function addWholeComment($value){
    if(isset($_POST['sendComment'])){
        global $url;
        $comment =$_POST['comment'];
        $cookie = $_COOKIE['id'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "$url/products/AddProductComment",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('product' => "$value",'user' => "$cookie",'comment' => "$comment" , 'vote'=>0),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $info = json_decode($response);
        if ($info->success == true) {
            echo "<script type='text/javascript'> document.location = 'yield?comment=true&id=$value'; </script>";
        } else {
            echo "<script type='text/javascript'> document.location = 'yield?comment=false&id=$value'; </script>";
        }
    }
}



