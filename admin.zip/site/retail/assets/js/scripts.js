$('a[href="#"]').on("click", function (e) {
    e.preventDefault();
});
(function () {
    $openMobileMenu = $(".mobile-menu-open");
    $closeMobileMenu = $(".mobile-menu-close");
    $mobileMenu = $(".mobile-menu");

    $openMobileMenu.click(function () {
        $mobileMenu.addClass("menu-opened");
    });
    $closeMobileMenu.click(function () {
        $mobileMenu.removeClass("menu-opened");
    });
})();
$(".mobile-search-btn").click(function (e) {
    e.preventDefault(),
        $(".mobile-search").css("top", "0px"),
        $(".mobile-search .search-form input[type='search']").focus();
});
$(".close-search").click(function (e) {
    e.preventDefault(), $(".mobile-search").css("top", "-100px");
});
var widthWin = $(window).width();
$(window).scroll(function () {
    if (widthWin > 768) {
        if ($(window).scrollTop() > 180) {
            if ($(window).scrollTop() > 570) {
                $(".jump-to-top-container").addClass("show");
            } else {
                $(".jump-to-top-container").removeClass("show");
            }
        }
    }
});

$("#jump-to-top").on("click", function (e) {
    e.preventDefault(), $("html,body").animate({ scrollTop: 0 }, 500);
});

var swiperHomeSlider = new Swiper(".home-slider", {
    navigation: {
        nextEl: ".home-slider-button-next",
        prevEl: ".home-slider-button-prev",
    },
    pagination: {
        el: ".home-slider-pagination",
    },
    autoplay: {
        delay: 5000,
    },
    speed: 300,
    effect: "fade",
    fadeEffect: {
        crossFade: true,
    },
    loop: true,
});
var swiperHomeGold = new Swiper(".home-gold-slider", {
    navigation: {
        nextEl: ".home-gold-slider-button-next",
        prevEl: ".home-gold-slider-button-prev",
    },
    pagination: {
        el: ".home-gold-slider-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 5000,
    },
    breakpoints: {
        0: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        576: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        768: {
            slidesPerView: 3,
            spaceBetween: 60,
        },
        992: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1200: {
            slidesPerView: 4,
            spaceBetween: 100,
        },
    },
    speed: 300,
});
var swiperHomeSilver = new Swiper(".home-silver-slider", {
    navigation: {
        nextEl: ".home-silver-slider-button-next",
        prevEl: ".home-silver-slider-button-prev",
    },
    pagination: {
        el: ".home-silver-slider-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 5000,
    },
    breakpoints: {
        0: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        576: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        768: {
            slidesPerView: 3,
            spaceBetween: 60,
        },
        992: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1200: {
            slidesPerView: 4,
            spaceBetween: 100,
        },
    },
    speed: 300,
});
var swiperGoldCat = new Swiper(".gold-category-slider", {
    navigation: {
        nextEl: ".gold-category-slider-button-next",
        prevEl: ".gold-category-slider-button-prev",
    },
    pagination: {
        el: ".gold-cat-slider-pagination",
    },
    autoplay: {
        delay: 5000,
    },
    speed: 300,
    effect: "fade",
    fadeEffect: {
        crossFade: true,
    },
    loop: true,
});
var swiperGoldProduct = new Swiper(".gold-category-product-slider", {
    navigation: {
        nextEl: ".gold-category-product-slider-button-next",
        prevEl: ".gold-category-product-slider-button-prev",
    },
    pagination: {
        el: ".gold-category-product-slider-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 5000,
    },
    breakpoints: {
        0: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        576: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        768: {
            slidesPerView: 4,
            spaceBetween: 60,
        },
        992: {
            slidesPerView: 4,
            spaceBetween: 30,
        },
        1200: {
            slidesPerView: 5,
            spaceBetween: 100,
        },
    },
    speed: 300,
});
var swiperHomeSilver = new Swiper(".product-similar-slider", {
    navigation: {
        nextEl: ".product-similar-slider-button-next",
        prevEl: ".product-similar-slider-button-prev",
    },
    pagination: {
        el: ".product-similar-slider-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 5000,
    },
    breakpoints: {
        0: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        576: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        768: {
            slidesPerView: 3,
            spaceBetween: 60,
        },
        992: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1200: {
            slidesPerView: 4,
            spaceBetween: 100,
        },
    },
    speed: 300,
});
var productSwiper = new Swiper(".product-swiper-container", {
    slidesPerView: 3,
    spaceBetween: 10,
    navigation: {
        nextEl: ".product-slider-button-next",
        prevEl: ".product-slider-button-prev",
    },
});

// $("#product-image").elevateZoom({
//     zoomType: "inner",
//     gallery: "product-gallery",
//     cursor: "crosshair",
//     galleryActiveClass: "active",
//     imageCrossfade: true,
//     easing: true,
// });
// //pass the images to Fancybox
// $("#product-image").bind("click", function (e) {
//     var ez = $("#product-image").data("elevateZoom");
//     $.fancybox(ez.getGalleryList());
//     return false;
// });
$("#product-image").elevateZoom({
    // zoomType: "inner",
    gallery: "product-gallery",
    // cursor: "crosshair",
    // galleryActiveClass: "active",
    imageCrossfade: true,
    zoomWindowPosition: 11,
    easing: true,
    // zoomWindowOffetx: 10,
});
//pass the images to Fancybox
$("#product-image").bind("click", function (e) {
    var ez = $("#product-image").data("elevateZoom");
    $.fancybox(ez.getGalleryList());
    return false;
});

$("input.once-checkbox:checkbox").on("click", function () {
    var $box = $(this);
    if ($box.is(":checked")) {
        var group = "input:checkbox[name='" + $box.attr("name") + "']";
        $(group).prop("checked", false);
        $box.prop("checked", true);
    } else {
        $box.prop("checked", false);
    }
});

$("#priceControlRange")
    .on("input", function () {
    $("#priceControlRange + .output").val(this.value + "0,000,000  ریال");
    })
.trigger("change");

// function logout() {
//     Swal.fire({
//         title: "خارج می‌شوید؟",
//         text: "You won't be able to revert this!",
//         icon: "warning",
//         showCancelButton: true,
//         confirmButtonColor: "#3085d6",
//         cancelButtonColor: "#d33",
//         cancelButtonText: "خیر",
//         confirmButtonText: "بله",
//     }).then((result) => {
//         if (result.isConfirmed) {
//             Swal.fire("خارج شدید", "شما از حساب کاربری خود خارج شدید!", "success");
//         }
//     });
// }