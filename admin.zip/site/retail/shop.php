<?php
include_once "../controller/controller.php";

$category = getCategories();
$collection = getCollactions();

$all = getAccess();
$access = $all[1];
$data = $all[0];
$color = $data[1];
$model = $data[2];
$offPercent = $data[7];
$weight = $data[10];
$count = $data[11];


signUp();
signIn();

if (isset($_GET['category'])) {
    $product = getProductsByCategory($_GET['category']);
    $categoryDesc = getDataById($_GET['category'], 'products/GetCategories');
    if(isset($_POST['filter'])){
        $product = filterData();
    }

} elseif (isset($_GET['collection'])) {
    $product = getProductsByCollection($_GET['collection']);
    $collection = getDataById($_GET['collection'], 'products/GetColactions');
    if(isset($_POST['filter'])){
        $product = filterData();
    }
} elseif (isset($_GET['search'])) {
    $product = getProductsBySearch($_GET['search']);
    if(isset($_POST['filter'])){
        $product = filterData();
    }
} elseif (isset($_GET['all'])) {
    $product = getAllProducts();
    if(isset($_POST['filter'])){
        $product = filterData();
    }
}
$about = getAbout();
addEmail();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فروشگاه</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/css/swiper.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://mondas.ir/site/retail/assets/css/style.css">
</head>

<body>
<header id="Site-Header">
    <div class="header-top container-xl py-1">
        <div class="row">
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-sign d-flex align-items-center h-100">
                    <?php if (isset($_COOKIE['name'])) : ?>
                        <button class="sign-btn btn btn-outline-dark rounded-pill" data-toggle="modal" data-target="#logoutmodal">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo $_COOKIE['name']; ?>
                                </span>
                        </button>
                        <!-- Modal: Logout Start -->
                        <div class="modal fade" id="logoutmodal" tabindex="-1" aria-labelledby="logoutmodalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">خروج از حساب کاربری</h5>
                                    </div>
                                    <div class="modal-body">
                                        <p class="mb-0">خارج می‌شوید؟</p>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">ادامه در سایت</button>
                                        <a href="exit" class="btn btn-danger">خروج</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Logout End -->
                    <?php else : ?>
                        <button class="sign-btn btn btn-outline-dark rounded-pill" data-toggle="modal" data-target="#modalLRForm">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo "ورود و ثبت نام"; ?>
                                </span>
                        </button>
                        <!-- Modal: Login / Register Start -->
                        <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#login-tab" role="tab">
                                                <i class="fas fa-user ml-1"></i>ورود</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#signin-tab" role="tab">
                                                <i class="fas fa-user-plus ml-1"></i>ثبت نام</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <!--- login --->
                                        <div class="tab-pane fade in show active" id="login-tab" role="tabpanel">
                                            <div class="modal-body mb-1">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" name="username" id="email-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-login">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password" id="password-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-login">رمز عبور</label>
                                                    </div>

                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signIn" type="submit">ورود
                                                            <i class="fas fa-user ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="options text-center text-md-right mt-1">
                                                </div>
                                                <button type="button" class="btn btn-outline-danger mr-auto" data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                        <!---- signUp---->
                                        <div class="tab-pane fade" id="signin-tab" role="tabpanel">
                                            <div class="modal-body">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="fullname-signup" name="fullName" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="fullname-signup">نام و نام خانوادگی</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="username-signup" name="username" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="username-signup">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="address-signup" name="address" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="address-signup">آدرس</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="number" placeholder="&nbsp;" id="phone-signup" name="phone" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="phone-signup">شماره تلفن همراه</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="email" placeholder="&nbsp;" id="email-signup" name="email" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-signup">ایمیل</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password" id="password-signup" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-signup">رمز عبور</label>
                                                    </div>
                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signUp" type="submit">ثبت نام
                                                            <i class="fas fa-user-plus ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-danger mr-auto" data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Login / Register End -->
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6 col-md-4 col-6">
                <div class="logo d-flex align-items-center justify-content-center h-100">
                    <a href="#" class="d-block"><img src="http://mondas.ir/site/retail/assets/images/logo.png"></a>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-search d-flex align-items-center h-100">
                    <form class="search-form position-relative d-none d-md-block w-100" method="GET"
                          action="shop?search=<?php echo $_GET['search'] ?>">
                        <input class="form-control" type="search" name="search" placeholder="جستجو..."
                               aria-label="Search">
                        <button class="btn position-absolute" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>
                    <div class="w-100 text-left d-block d-md-none">
                        <button class="btn btn-outline-dark mobile-search-btn rounded-pill">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="mobile-search position-absolute w-100 py-4 bg-white">
                <div class="container">
                    <div class="row">
                        <span class="close-search col-2">بستن</span>
                        <div class="col-10">
                            <form class="search-form position-relative d-block d-md-none w-100" method="GET"
                                  action="shop?search=<?php echo $_GET['search'] ?>">
                                <input class="form-control" type="search" name="search" placeholder="جستجو..."
                                       aria-label="Search">
                                <button class="btn position-absolute" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom container-xl py-2">
        <div class="row">
            <div class="col-md-2 col-6">
                <a href="cart" >
                    <i class="fa fa-shopping-cart"></i>
                </a>
            </div>
            <div class="col-8 d-none d-md-block">
                <ul class="nav pis justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link" href="home">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="shop?all">فروشگاه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Site-Footer">درباره ما</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">مقالات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Site-Footer">تماس با ما</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-2 col-6">
                    <span class="btn mobile-menu-open d-md-none m-auto float-left">
                        <i class="fa fa-bars"></i>
                    </span>
            </div>
        </div>
    </div>
   
</header>
<div class="mobile-menu">
        <span class="mobile-menu-close">
            <i class="fa fa-times"></i>
        </span>
    <ul class="menu">
        <li class="menu-item">
            <a href="home">خانه</a>
        </li>
        <li class="menu-item">
            <a href="shop?all">فروشگاه</a>
        </li>
        <li class="menu-item">
            <a href="#Site-Footer">درباره ما</a>
        </li>
        <li class="menu-item">
            <a href="#">مقالات</a>
        </li>
        <li class="menu-item">
            <a href="#Site-Footer">تماس با ما</a>
        </li>
    </ul>
</div>

<main>
    <div id="Site-Wrapper" class="shop container-xl">
        <div class="row py-3 py-md-5">
            <div class="shop-side col-xl-2 col-md-3 border-left pb-5 pb-md-0">
                 <form class="accordion filter-product" id="filterProduct" method="post">
                    <?php if ($access[4]->قیمت == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-1" data-toggle="collapse"
                                 data-target="#collapse-1" aria-expanded="true" aria-controls="collapse-1">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    بیشترین قیمت<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-1" class="collapse show" aria-labelledby="heading-1"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <input type="range" name="range" class="form-control-range" id="priceControlRange"
                                           min="1" max="99" step="1" value="99">
                                    <output for="priceControlRange" class="output"></output>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[9]->جنسیت == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-2" data-toggle="collapse"
                                 data-target="#collapse-2" aria-expanded="false" aria-controls="collapse-2">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس جنسیت<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-2" class="collapse" aria-labelledby="heading-2"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="gender"
                                               value="men"
                                               id="filterageMen">
                                        <label for="filterageMen">
                                            <span class="check-span"></span> مردانه
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="gender"
                                               value="women"
                                               id="filterageWomen">
                                        <label for="filterageWomen">
                                            <span class="check-span"></span> زنانه
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="gender"
                                               value="both"
                                               id="filterageAllGenders">
                                        <label for="filterageAllGenders">
                                            <span class="check-span"></span> هردو
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[5]->دسته == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-3" data-toggle="collapse"
                                 data-target="#collapse-3" aria-expanded="false" aria-controls="collapse-3">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس دسته بندی<i class="fa fa-plus"></i>
                                </span>
                            </div>
                            <div id="collapse-3" class="collapse" aria-labelledby="heading-3"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <?php
                                    if (!empty($category)) {
                                        foreach ($category as $item) {
                                            ?>
                                            <div class="checkbox">
                                                <input class="form-check-input" type="checkbox" name="category[]"
                                                       value="<?php echo $item->id ?>"
                                                       id="filtertype<?php echo $item->id ?>">
                                                <label for="filtertype<?php echo $item->id ?>">
                                                    <span class="check-span"></span><?php echo $item->title ?>
                                                </label>
                                            </div>
                                        <?php }
                                    } ?>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[6]->جنس == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-4" data-toggle="collapse"
                                 data-target="#collapse-4" aria-expanded="false" aria-controls="collapse-4">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس نوع<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-4" class="collapse" aria-labelledby="heading-4"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="gens"
                                               value="True"
                                               id="filtertypeGold">
                                        <label for="filtertypeGold">
                                            <span class="check-span"></span>طلا
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="gens"
                                               value="False"
                                               id="filtertypeSilver">
                                        <label for="filtertypeSilver">
                                            <span class="check-span"></span>نقره
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[8]->تخفیف == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-5" data-toggle="collapse"
                                 data-target="#collapse-5" aria-expanded="false" aria-controls="collapse-5">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس تخفیف<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-5" class="collapse" aria-labelledby="heading-5"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="off"
                                               value="True"
                                               id="filtertypeOff">
                                        <label for="filtertypeOff">
                                            <span class="check-span"></span>دارد
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="off"
                                               value="False"
                                               id="filtertypeNoOff">
                                        <label for="filtertypeNoOff">
                                            <span class="check-span"></span>ندارد
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[0]->کالکشن == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-3" data-toggle="collapse"
                                 data-target="#collapse-6" aria-expanded="false" aria-controls="collapse-6">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس کالکشن<i class="fa fa-plus"></i>
                                </span>
                            </div>
                            <div id="collapse-6" class="collapse" aria-labelledby="heading-6"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <?php
                                    if (!empty($collection)) {
                                        foreach ($collection as $item) {
                                            ?>
                                            <div class="checkbox">
                                                <input class="form-check-input" type="checkbox" name="collection[]"
                                                       value="<?php echo $item->id ?>"
                                                       id="filtertypeCol<?php echo $item->id ?>">
                                                <label for="filtertypeCol<?php echo $item->id ?>">
                                                    <span class="check-span"></span><?php echo $item->title ?>
                                                </label>
                                            </div>
                                        <?php }
                                    } ?>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[3]->عیار == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-8" data-toggle="collapse"
                                 data-target="#collapse-8" aria-expanded="false" aria-controls="collapse-8">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس عیار<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-8" class="collapse" aria-labelledby="heading-8"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="carat"
                                               value="18"
                                               id="filtertypeEighteen">
                                        <label for="filtertypeEighteen">
                                            <span class="check-span"></span>۱۸عیار
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="carat"
                                               value="24"
                                               id="filtertypeTwentyFour">
                                        <label for="filtertypeTwentyFour">
                                            <span class="check-span"></span>۲۴عیار
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[11]->تعداد == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-9" data-toggle="collapse"
                                 data-target="#collapse-9" aria-expanded="false" aria-controls="collapse-9">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس تعداد<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-9" class="collapse" aria-labelledby="heading-9"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <?php
                                    foreach ($count->attribute as $value) {
                                    ?>
                                    <div class="checkbox">
                                            <input class="form-check-input once-checkbox" type="checkbox" name="<?php echo $value->name  ?>"
                                                   value="<?php echo $value->attribute  ?>"
                                                   id="filtertype<?php echo $value->attribute ?>">
                                            <label for="filtertype<?php echo $value->attribute ?>">
                                                <span class="check-span"></span><?php echo $value->attribute ?>
                                            </label>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[10]->وزن == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-10" data-toggle="collapse"
                                 data-target="#collapse-10" aria-expanded="false" aria-controls="collapse-10">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس وزن<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-10" class="collapse" aria-labelledby="heading-10"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <?php
                                    foreach ($weight->attribute as $value) {
                                    ?>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="<?php echo $value->name  ?>"
                                               value="<?php echo $value->attribute ?>"
                                               id="filtertypeE<?php echo $value->attribute ?>">
                                        <label for="filtertypeE<?php echo $value->attribute ?>">
                                            <span class="check-span"></span><?php echo $value->attribute ?>
                                        </label>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[7]->درصدتخفیف == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-11" data-toggle="collapse"
                                 data-target="#collapse-11" aria-expanded="false" aria-controls="collapse-11">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس درصد تخفیف<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-11" class="collapse" aria-labelledby="heading-11"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <?php
                                    foreach ($offPercent->attribute as $value) {
                                    ?>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="<?php echo $value->name ?>"
                                               value="<?php echo $value->attribute ?>"
                                               id="filtertypeEi<?php echo $value->attribute ?>">
                                        <label for="filtertypeEi<?php echo $value->attribute ?>">
                                            <span class="check-span"></span><?php echo $value->attribute ?>
                                        </label>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[1]->رنگ == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-12" data-toggle="collapse"
                                 data-target="#collapse-12" aria-expanded="false" aria-controls="collapse-12">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس رنگ<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-12" class="collapse" aria-labelledby="heading-12"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <?php
                                    foreach ($color->attribute as $value) {
                                    ?>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="<?php echo $value->name ?>"
                                               value="<?php echo $value->attribute ?>"
                                               id="filtertypeEigh<?php echo $value->attribute ?>">
                                        <label for="filtertypeEigh<?php echo $value->attribute ?>">
                                            <span class="check-span"></span><?php echo $value->attribute ?>
                                        </label>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php }
                    if ($access[2]->مدل == 1) { ?>
                        <div class="card border-0 mb-2 mb-md-4">
                            <div class="card-header border-0 bg-transparent" id="heading-13" data-toggle="collapse"
                                 data-target="#collapse-13" aria-expanded="false" aria-controls="collapse-13">
                                <span class="align-items-center d-flex justify-content-between no-focus">
                                    براساس مدل<i class="fa fa-plus"></i>
                                </span>
                            </div>

                            <div id="collapse-13" class="collapse" aria-labelledby="heading-13"
                                 data-parent="#filterProduct">
                                <div class="card-body">
                                    <?php
                                    foreach ($model->attribute as $value) {
                                    ?>
                                    <div class="checkbox">
                                        <input class="form-check-input once-checkbox" type="checkbox" name="<?php echo $value->name ?>"
                                               value="<?php echo $value->attribute ?>"
                                               id="filtertypeEighteen<?php echo $value->attribute ?>">
                                        <label for="filtertypeEighteen<?php echo $value->attribute ?>">
                                            <span class="check-span"></span><?php echo $value->attribute ?>
                                        </label>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>


                    <input class="btn btn-block cta-btn" type="submit" name="filter" value="فیلتربندی">
                </form>
            </div>
            <div class="shop-product col-xl-10 col-md-9">
                <div class="row no-gutters">

                    <!--description-->

                    <?php
                    if (isset($_GET['category'])) {
                        ?>

                        <div class="col-12 mb-3">
                            <div class="shop-description py-3 px-2">
                                <p><?php echo $categoryDesc->description ?></p>
                            </div>
                        </div>

                    <?php } elseif (isset($_GET['collection'])) {
                        ?>

                        <div class="col-12 mb-3">
                            <div class="shop-description py-3 px-2">
                                <p><?php echo $collection->description ?></p>
                            </div>
                        </div>

                    <?php } ?>

                    <!--products-->

                    <?php
                    if (!empty($product)) {
                        foreach ($product as $item) {
                            ?>
                            <div class="col-xl-3 col-md-4 col-sm-6 mb-3">
                                <a href="commodity?id=<?php echo $item->id ?>"
                                   class="card border-0 text-dark float-inner nohover h-100">
                                    <div class="card-img-top">
                                        <img src="<?php echo $item->image[0]->image ?>">
                                    </div>
                                    <div class="card-body d-flex flex-column justify-content-end">
                                        <ul class="pis list-inline">
                                            <li class="mb-2">
                                                    <span class="font-weight-bold">مدل:
                                                    </span><?php echo $item->model ?>
                                            </li>
                                            <li class="mb-2">
                                                    <span class="font-weight-bold">وزن:
                                                    </span><?php echo $item->weight ?>
                                            </li>
                                            <li class="mb-2">
                                                    <span class="font-weight-bold">قیمت:
                                                    </span><?php echo number_format($item->price) ?>
                                                <span class="price-symbol">ریال</span>
                                            </li>
                                        </ul>
                                        <button class="btn rounded-pill cta-btn-primary d-block my-0 mx-auto px-5">بیشتر
                                        </button>
                                    </div>
                                </a>
                            </div>
                        <?php }
                    } ?>

                </div>
            </div>
        </div>
    </div>
</main>

<footer id="Site-Footer">
    <div class="footer-top container-xl py-3 py-lg-5">
        <div class="row">
            <div class="footer-column-1 col-sm-6 col-lg-3">
                <ul class="footer-menu list-inline pis text-center text-lg-right">
                    <li class="mb-3">
                        <a href="shop?all" class="p-2 text-dark">محصولات</a>
                    </li>
                    <li class="mb-3">
                        <a href="#" class="p-2 text-dark">مقالات</a>
                    </li>
                </ul>
            </div>
            <div class="footer-column-2 col-lg-6">
                <div class="logo text-center mb-4">
                    <a href="#"><img src="http://mondas.ir/site/retail/assets/images/logo.png"></a>
                </div>
                <h4 class="w-100 text-center">خبرنامه</h4>
                <p class="text-center">با وارد کردن ایمیل از جدید ترین محصولات ما با خبر شوید</p>
                <div class="container-fluid subscribe-news py-3">
                    <form class="form-inline mx-auto position-relative w-100" method="post">
                        <input type="email" class="form-control w-100" name="email" placeholder="ایمیل خود را وارد کنید" required>
                        <button type="submit" name="add" class="btn position-absolute">عضویت</button>
                    </form>
                </div>
            </div>
            <div class="footer-column-3 col-sm-6 col-lg-3">
                <div class="namad-container d-flex justify-content-between flex-column">
                    <div class="namad">
                        <a href="#"><img src="http://mondas.ir/site/retail/assets/images/enamad-logo.png"></a>
                    </div>
                    <!-- <div class="namad">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        <a href="#"><img src="assets/images/resane-logo.png"></a>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   </div> -->
                </div>
                <div class="social-icons">
                    <ul class="pis d-flex justify-content-center">
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-instagram-square"></i>
                            </a>
                        </li>
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-telegram"></i>
                            </a>
                        </li>
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-whatsapp-square"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom container-xl py-3">
        <div class="row">
            <div class="col-12">
                <div class="footer-contact m-auto text-center w-50">
                    <div class="address d-flex justify-content-center align-items-center w-100 mb-2">
                        <i class="fa fa-map-marker-alt ml-3 tm-color"></i>
                        <p class="mb-0"><?php echo $about->addres  ?></p>
                    </div>
                    <div class="phone d-flex justify-content-center align-items-center w-100">
                        <i class="fa fa-phone ml-3 tm-color"></i>
                        <ul class="pis mb-0 list-inline d-flex">
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone1  ?></a>
                            </li>
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone2  ?></a>
                            </li>
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone3  ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<span id="jump-to-top" class="shadows jump-to-top-container tm-color">
        <i class="fa fa-chevron-up"></i>
    </span>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/js/swiper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.bundle.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/2.2.3/jquery.elevatezoom.min.js'></script>
<script src="http://mondas.ir/site/retail/assets/js/scripts.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php
if (isset($_GET['add'])) {
    if ($_GET['add'] == "true") {
        echo "<script>swal(' باتشکر!','محصول شما به سبد خرید افزوده شد', 'success');</script>";
    } elseif ($_GET['add'] == "false") {
        echo "<script>swal('متاسفیم', 'محصول شما به سبدخرید اضافه نشد', 'error');</script>";
    }
}
?>

</body>

</html>