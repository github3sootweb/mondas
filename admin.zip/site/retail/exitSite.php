<?php
setcookie("id", "", time() - 3600);
setcookie("cart", "", time() - 3600);
setcookie("name", "", time() - 3600);
echo "<script type='text/javascript'> document.location = 'home?logout'; </script>";
?>