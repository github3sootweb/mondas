<?php
include_once "../controller/controller.php";
$slider = getSliders('first_page');
$bestGolds = bestGolds();
$bestSilvers = bestSilvers();
$about = getAbout();
signUp();
signIn();
addEmail();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه اصلی</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/css/swiper.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://mondas.ir/site/retail/assets/css/style.css">
</head>

<body>
<header id="Site-Header">
    <div class="header-top container-xl py-1">
        <div class="row">
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-sign d-flex align-items-center h-100">
                    <?php if (isset($_COOKIE['name'])) : ?>
                        <button class="sign-btn btn btn-outline-dark rounded-pill" data-toggle="modal" data-target="#logoutmodal">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo $_COOKIE['name']; ?>
                                </span>
                        </button>
                        <!-- Modal: Logout Start -->
                        <div class="modal fade" id="logoutmodal" tabindex="-1" aria-labelledby="logoutmodalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">خروج از حساب کاربری</h5>
                                    </div>
                                    <div class="modal-body">
                                        <p class="mb-0">خارج می‌شوید؟</p>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">ادامه در سایت</button>
                                        <a href="exit" class="btn btn-danger">خروج</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Logout End -->
                    <?php else : ?>
                        <button class="sign-btn btn btn-outline-dark rounded-pill" data-toggle="modal" data-target="#modalLRForm">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo "ورود و ثبت نام"; ?>
                                </span>
                        </button>
                        <!-- Modal: Login / Register Start -->
                        <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#login-tab" role="tab">
                                                <i class="fas fa-user ml-1"></i>ورود</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#signin-tab" role="tab">
                                                <i class="fas fa-user-plus ml-1"></i>ثبت نام</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <!--- login --->
                                        <div class="tab-pane fade in show active" id="login-tab" role="tabpanel">
                                            <div class="modal-body mb-1">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" name="username" id="email-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-login">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password" id="password-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-login">رمز عبور</label>
                                                    </div>

                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signIn" type="submit">ورود
                                                            <i class="fas fa-user ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="options text-center text-md-right mt-1">
                                                </div>
                                                <button type="button" class="btn btn-outline-danger mr-auto" data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                        <!---- signUp---->
                                        <div class="tab-pane fade" id="signin-tab" role="tabpanel">
                                            <div class="modal-body">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="fullname-signup" name="fullName" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="fullname-signup">نام و نام خانوادگی</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="username-signup" name="username" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="username-signup">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="address-signup" name="address" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="address-signup">آدرس</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="number" placeholder="&nbsp;" id="phone-signup" name="phone" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="phone-signup">شماره تلفن همراه</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="email" placeholder="&nbsp;" id="email-signup" name="email" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-signup">ایمیل</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password" id="password-signup" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-signup">رمز عبور</label>
                                                    </div>
                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signUp" type="submit">ثبت نام
                                                            <i class="fas fa-user-plus ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-danger mr-auto" data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Login / Register End -->
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6 col-md-4 col-6">
                <div class="logo d-flex align-items-center justify-content-center h-100">
                    <a href="" class="d-block"><img src="http://mondas.ir/site/retail/assets/images/logo.png"></a>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-search d-flex align-items-center h-100">
                    <form class="search-form position-relative d-none d-md-block w-100" method="GET"
                          action="shop?search=<?php echo $_GET['search'] ?>">
                        <input class="form-control" type="search" name="search" placeholder="جستجو..."
                               aria-label="Search">
                        <button class="btn position-absolute" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>
                    <div class="w-100 text-left d-block d-md-none">
                        <button class="btn btn-outline-dark mobile-search-btn rounded-pill">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="mobile-search position-absolute w-100 py-4 bg-white">
                <div class="container">
                    <div class="row">
                        <span class="close-search col-2">بستن</span>
                        <div class="col-10">
                            <form class="search-form position-relative d-block d-md-none w-100" method="GET"
                                  action="shop?search=<?php echo $_GET['search'] ?>">
                                <input class="form-control" type="search" name="search" placeholder="جستجو..."
                                       aria-label="Search">
                                <button class="btn position-absolute" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom container-xl py-2">
        <div class="row">
            <div class="col-md-2 col-6">
                <a href="cart">
                    <i class="fa fa-shopping-cart"></i>
                </a>
            </div>
            <div class="col-8 d-none d-md-block">
                <ul class="nav pis justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="home">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="shop?all">فروشگاه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Site-Footer">درباره ما</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">مقالات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Site-Footer">تماس با ما</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-2 col-6">
                    <span class="btn mobile-menu-open d-md-none m-auto float-left">
                        <i class="fa fa-bars"></i>
                    </span>
            </div>
        </div>
    </div>
</header>
<div class="mobile-menu">
    <span class="mobile-menu-close"><i class="fa fa-times"></i></span>
    <ul class="menu">
        <li class="menu-item">
            <a href="home">خانه</a>
        </li>
        <li class="menu-item">
            <a href="shop?all">فروشگاه</a>
        </li>
        <li class="menu-item">
            <a href="#Site-Footer">درباره ما</a>
        </li>
        <li class="menu-item">
            <a href="#">مقالات</a>
        </li>
        <li class="menu-item">
            <a href="#Site-Footer">تماس با ما</a>
        </li>
    </ul>
</div>

<main>
    <section class="slider-area container-xl">
        <div class="home-slider swiper-container">
            <div class="swiper-wrapper">
                <?php
                if (!empty($slider)) {
                    foreach ($slider as $item) {
                        ?>
                        <div class="swiper-slide"
                             style="background-color: #343434;background-image:url('<?php echo $item->image ?>');">
                            <div class="d-flex justify-content-around align-items-center flex-column py-5 h-100">
                                <img src="<?php echo $item->image ?>">
                                <h2 class="text-light"><?php echo $item->title ?></h2>
                                <a href="<?php echo $item->url ?>" class="btn cta-btn rounded-pill">بیشتر بخوانید</a>
                            </div>
                        </div>
                    <?php }
                } ?>
            </div>
            <div class="home-slider-pagination swiper-pagination"></div>
            <div class="home-slider-button-next swiper-button-next"></div>
            <div class="home-slider-button-prev swiper-button-prev"></div>
        </div>
    </section>
    <div id="Site-Wrapper" class="container-xl">
        <section class="categories row py-3 py-md-5">
            <div class="col-md-6">
                <div class="px-lg-5 px-md-3 px-1">
                    <div class="card bg-transparent border-0">
                        <div class="card-body">
                            <h2 class="card-text text-center">
                                <a href="gold" class="text-dark">ورود به بخش محصولات طلا</a>
                            </h2>
                        </div>
                        <a href="gold" class="card-img position-relative overflow-hidden">
                            <img src="http://mondas.ir/site/retail/assets/images/01.jpg" class="card-img-bottom">
                            <div class="overlay">
                                    <span class="tm-color w-100 text-center">مشاهده محصولات<i
                                                class="fa fa-chevron-left mr-2"></i>
                                    </span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="px-lg-5 px-md-3 px-1">
                    <div class="card bg-transparent border-0">
                        <div class="card-body">
                            <h2 class="card-text text-center">
                                <a href="silver" class="text-dark">ورود به بخش محصولات نقره</a>
                            </h2>
                        </div>
                        <a href="silver" class="card-img position-relative overflow-hidden">
                            <img src="http://mondas.ir/site/retail/assets/images/02.jpg" class="card-img-bottom">
                            <div class="overlay">
                                    <span class="tm-color w-100 text-center">مشاهده محصولات<i
                                                class="fa fa-chevron-left mr-2"></i>
                                    </span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section class="features row py-3 py-md-5">
            <div class="features-wrapper col-lg-3 col-6 mb-md-0 mb-4">
                <div class="card border-0 float-top">
                    <div class="card-img d-flex justify-content-center align-items-center py-5">
                        <i class="fa fa-tag"></i>
                    </div>
                    <div class="card-body">
                        <h4 class="card-text text-center">گارانتی محصولات</h4>
                    </div>
                </div>
            </div>
            <div class="features-wrapper col-lg-3 col-6 mb-md-0 mb-4">
                <div class="card border-0 float-top">
                    <div class="card-img d-flex justify-content-center align-items-center py-5">
                        <i class="fa fa-shopping-cart"></i>
                    </div>
                    <div class="card-body">
                        <h4 class="card-text text-center">خرید 24 ساعته</h4>
                    </div>
                </div>
            </div>
            <div class="features-wrapper col-lg-3 col-6 mb-md-0 mb-4">
                <div class="card border-0 float-top">
                    <div class="card-img d-flex justify-content-center align-items-center py-5">
                        <i class="fa fa-headset"></i>
                    </div>
                    <div class="card-body">
                        <h4 class="card-text text-center">پشتیبانی آنلاین</h4>
                    </div>
                </div>
            </div>
            <div class="features-wrapper col-lg-3 col-6 mb-md-0 mb-4">
                <div class="card border-0 float-top">
                    <div class="card-img d-flex justify-content-center align-items-center py-5">
                        <i class="fa fa-truck"></i>
                    </div>
                    <div class="card-body">
                        <h4 class="card-text text-center">ارسال سریع</h4>
                    </div>
                </div>
            </div>
        </section>
        <section class="gold-products row">
            <div class="col-12">
                <h2 class="position-relative w-100 text-center mb-4">محصولات محبوب طلا</h2>
                <div class="home-gold-slider swiper-container py-5 px-4">
                    <div class="swiper-wrapper">
                        <?php
                        if (!empty($bestGolds)) {
                            foreach ($bestGolds as $item) {
                                ?>
                                <div class="swiper-slide">
                                    <a href="commodity?id=<?php echo $item->id ?>"
                                       class="card h-100 border-0 text-dark float-top nohover">
                                        <div class="card-img-top">

                                            <img src="<?php
                                            echo $item->image[0]->image
                                            ?>">

                                        </div>
                                        <div class="card-body d-flex flex-column justify-content-end">
                                            <ul class="pis list-inline">
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">مدل:
                                                        </span><?php echo $item->model ?>
                                                </li>
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">وزن:
                                                        </span><?php echo $item->weight ?>
                                                </li>
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">قیمت:
                                                        </span><?php echo number_format($item->price) ?>
                                                    <span class="price-symbol">ریال</span>
                                                </li>
                                            </ul>
                                            <button class="btn rounded-pill cta-btn-primary d-block m-auto px-5">بیشتر
                                            </button>
                                        </div>
                                    </a>
                                </div>
                            <?php }
                        } ?>
                    </div>
                    <!-- <div class="home-gold-slider-pagination swiper-pagination"></div> -->
                    <div class="home-gold-slider-button-next swiper-button-next"></div>
                    <div class="home-gold-slider-button-prev swiper-button-prev"></div>
                </div>
            </div>
        </section>
        <section class="silver-products row ">
            <div class="col-12">
                <h2 class="position-relative w-100 text-center mb-4">محصولات محبوب نقره</h2>
                <div class="home-silver-slider swiper-container py-5 px-4">
                    <div class="swiper-wrapper">
                        <?php
                        if (!empty($bestSilvers)) {
                            foreach ($bestSilvers as $item) {
                                ?>
                                <div class="swiper-slide">
                                    <a href="commodity?id=<?php echo $item->id ?>"
                                       class="card h-100 border-0 text-dark float-top nohover">
                                        <div class="card-img-top">
                                            <img class="img-fluid" src="<?php
                                            echo $item->image[0]->image
                                            ?>">
                                        </div>
                                        <div class="card-body d-flex flex-column justify-content-end">
                                            <ul class="pis list-inline">
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">مدل:
                                                        </span><?php echo $item->model ?>
                                                </li>
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">وزن:
                                                        </span><?php echo $item->weight ?>
                                                </li>
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">قیمت:
                                                        </span><?php echo number_format($item->price) ?>
                                                    <span class="price-symbol">ریال</span>
                                                </li>
                                            </ul>
                                            <button class="btn rounded-pill cta-btn-primary d-block m-auto px-5">بیشتر
                                            </button>
                                        </div>
                                    </a>
                                </div>
                            <?php }
                        } ?>
                    </div>
                    <!-- <div class="home-silver-slider-pagination swiper-pagination"></div> -->
                    <div class="home-silver-slider-button-next swiper-button-next"></div>
                    <div class="home-silver-slider-button-prev swiper-button-prev"></div>
                </div>
            </div>
        </section>
    </div>
</main>

<footer id="Site-Footer">
    <div class="footer-top container-xl py-3 py-lg-5">
        <div class="row">
            <div class="footer-column-1 col-sm-6 col-lg-3">
                <ul class="footer-menu list-inline pis text-center text-lg-right">
                    <li class="mb-3">
                        <a href="shop?all" class="p-2 text-dark">محصولات</a>
                    </li>
                    <li class="mb-3">
                        <a href="#" class="p-2 text-dark">مقالات</a>
                    </li>
                </ul>
            </div>
            <div class="footer-column-2 col-lg-6">
                <div class="logo text-center mb-4">
                    <a href="#"><img src="http://mondas.ir/site/retail/assets/images/logo.png"></a>
                </div>
                <h4 class="w-100 text-center">خبرنامه</h4>
                <p class="text-center">با وارد کردن ایمیل از جدید ترین محصولات ما با خبر شوید</p>
                <div class="container-fluid subscribe-news py-3">
                    <form class="form-inline mx-auto position-relative w-100" method="post">
                        <input type="email" class="form-control w-100" name="email" placeholder="ایمیل خود را وارد کنید" required>
                        <button type="submit" name="add" class="btn position-absolute">عضویت</button>
                    </form>
                </div>
            </div>
            <div class="footer-column-3 col-sm-6 col-lg-3">
                <div class="namad-container d-flex justify-content-between flex-column">
                    <div class="namad">
                        <a href="#"><img src="http://mondas.ir/site/retail/assets/images/enamad-logo.png"></a>
                    </div>
                    <!-- <div class="namad">
                                                                                                                                                                                                                                                                          <a href="#"><img src="assets/images/resane-logo.png"></a>
                                                                                                                                                                                                                                                                     </div> -->
                </div>
                <div class="social-icons">
                    <ul class="pis d-flex justify-content-center">
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-instagram-square"></i>
                            </a>
                        </li>
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-telegram"></i>
                            </a>
                        </li>
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-whatsapp-square"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom container-xl py-3">
        <div class="row">
            <div class="col-12">
                <div class="footer-contact m-auto text-center w-50">
                    <div class="address d-flex justify-content-center align-items-center w-100 mb-2">
                        <i class="fa fa-map-marker-alt ml-3 tm-color"></i>
                        <p class="mb-0"><?php echo $about->addres  ?></p>
                    </div>
                    <div class="phone d-flex justify-content-center align-items-center w-100">
                        <i class="fa fa-phone ml-3 tm-color"></i>
                        <ul class="pis mb-0 list-inline d-flex">
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone1  ?></a>
                            </li>
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone2  ?></a>
                            </li>
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone3  ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<span id="jump-to-top" class="shadows jump-to-top-container tm-color">
        <i class="fa fa-chevron-up"></i>
    </span>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/js/swiper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.bundle.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/2.2.3/jquery.elevatezoom.min.js'></script>
<script src="http://mondas.ir/site/retail/assets/js/scripts.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
if (isset($_GET['login'])) {
    if ($_GET['login'] == "true") {
        echo "<script>swal('خوش آمدید!','ورود شما با موفقیت انجام شد', 'success');</script>";
    } elseif ($_GET['login'] == "false") {
        echo "<script>swal('متاسفیم', ' ورود با موفقیت انجام نشد', 'error');</script>";
    } elseif ($_GET['disable']) {
         echo "<script>swal('متاسفیم', ' ورود با موفقیت انجام نشد', 'error');</script>";
}
}

if (isset($_GET['signUp'])) {
    if ($_GET['signUp'] == "true") {
        echo "<script>swal('خوش آمدید!','ثبت نام شما با موفقیت انجام شد', 'success');</script>";
    } elseif ($_GET['signUp'] == "false") {
        echo "<script>swal('متاسفیم', ' ثبت نام با موفقیت انجام نشد', 'error');</script>";
    }
}

if (isset($_GET['email'])) {
    if ($_GET['email'] == "true") {
        echo "<script>swal('باتشکر!','ایمیل شما ثبت گردید', 'success');</script>";
    } elseif ($_GET['email'] == "false") {
        echo "<script>swal('متاسفیم', ' ایمیل شما ثبت نگردید', 'error');</script>";
    }
}

if (isset($_GET['logout'])) {
    echo "<script>swal(' باتشکر!','شما با موفقیت از حساب کاربری خود خارج شدید', 'success');</script>";
}


?>
</body>

</html>