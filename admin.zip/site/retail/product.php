<?php
include_once "../controller/controller.php";
if (isset($_GET['id'])) {
    $product = getDataById($_GET['id'], 'products/GetProducts');
    $random = getRandomData();

    if (!isset($_COOKIE['cart'])) {
        addCart($_GET['id']);
    } else {
        addProductTocart($_GET['id']);
    }

    addLetMeKnow($_GET['id']);

    addComment($_GET['id']);
}
$about = getAbout();
signUp();
signIn();
addEmail();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>محصول</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/css/swiper.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css" />
    <link rel="stylesheet" href="http://mondas.ir/site/retail/assets/css/style.css">
</head>

<body>
<header id="Site-Header">
    <div class="header-top container-xl py-1">
        <div class="row">
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-sign d-flex align-items-center h-100">
                    <?php if (isset($_COOKIE['name'])) : ?>
                        <button class="sign-btn btn btn-outline-dark rounded-pill" data-toggle="modal" data-target="#logoutmodal">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo $_COOKIE['name']; ?>
                                </span>
                        </button>
                        <!-- Modal: Logout Start -->
                        <div class="modal fade" id="logoutmodal" tabindex="-1" aria-labelledby="logoutmodalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">خروج از حساب کاربری</h5>
                                    </div>
                                    <div class="modal-body">
                                        <p class="mb-0">خارج می‌شوید؟</p>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">ادامه در سایت</button>
                                        <a href="exit" class="btn btn-danger">خروج</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Logout End -->
                    <?php else : ?>
                        <button class="sign-btn btn btn-outline-dark rounded-pill" data-toggle="modal" data-target="#modalLRForm">
                            <i class="fa fa-user ml-md-2"></i>
                            <span class="d-none d-md-inline-block">
                                    <?php echo "ورود و ثبت نام"; ?>
                                </span>
                        </button>
                        <!-- Modal: Login / Register Start -->
                        <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#login-tab" role="tab">
                                                <i class="fas fa-user ml-1"></i>ورود</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#signin-tab" role="tab">
                                                <i class="fas fa-user-plus ml-1"></i>ثبت نام</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <!--- login --->
                                        <div class="tab-pane fade in show active" id="login-tab" role="tabpanel">
                                            <div class="modal-body mb-1">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" name="username" id="email-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-login">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password" id="password-login" class="form-control">
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-login">رمز عبور</label>
                                                    </div>

                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signIn" type="submit">ورود
                                                            <i class="fas fa-user ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="options text-center text-md-right mt-1">
                                                </div>
                                                <button type="button" class="btn btn-outline-danger mr-auto" data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                        <!---- signUp---->
                                        <div class="tab-pane fade" id="signin-tab" role="tabpanel">
                                            <div class="modal-body">
                                                <form method="post">
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="fullname-signup" name="fullName" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="fullname-signup">نام و نام خانوادگی</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="username-signup" name="username" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="username-signup">نام کاربری</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="text" placeholder="&nbsp;" id="address-signup" name="address" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="address-signup">آدرس</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="number" placeholder="&nbsp;" id="phone-signup" name="phone" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="phone-signup">شماره تلفن همراه</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="email" placeholder="&nbsp;" id="email-signup" name="email" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="email-signup">ایمیل</label>
                                                    </div>
                                                    <div class="form-group has-float-label">
                                                        <input type="password" placeholder="&nbsp;" name="password" id="password-signup" class="form-control" required>
                                                        <span class="form-bar"></span>
                                                        <label class="float-label" for="password-signup">رمز عبور</label>
                                                    </div>
                                                    <div class="text-center mt-2">
                                                        <button class="btn btn-block cta-btn" name="signUp" type="submit">ثبت نام
                                                            <i class="fas fa-user-plus ml-1"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-danger mr-auto" data-dismiss="modal">بستن
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal: Login / Register End -->
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6 col-md-4 col-6">
                <div class="logo d-flex align-items-center justify-content-center h-100">
                    <a href="#" class="d-block"><img src="http://mondas.ir/site/retail/assets/images/logo.png"></a>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-3">
                <div class="header-search d-flex align-items-center h-100">
                    <form class="search-form position-relative d-none d-md-block w-100" method="GET" action="shop?search=<?php echo $_GET['search'] ?>">
                        <input class="form-control" type="search" name="search" placeholder="جستجو..." aria-label="Search">
                        <button class="btn position-absolute" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>
                    <div class="w-100 text-left d-block d-md-none">
                        <button class="btn btn-outline-dark mobile-search-btn rounded-pill">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="mobile-search position-absolute w-100 py-4 bg-white">
                <div class="container">
                    <div class="row">
                        <span class="close-search col-2">بستن</span>
                        <div class="col-10">
                            <form class="search-form position-relative d-block d-md-none w-100" method="GET" action="shop?search=<?php echo $_GET['search'] ?>">
                                <input class="form-control" type="search" name="search" placeholder="جستجو..." aria-label="Search">
                                <button class="btn position-absolute" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom container-xl py-2">
        <div class="row">
            <div class="col-md-2 col-6">
                <a href="cart">
                    <i class="fa fa-shopping-cart"></i>
                </a>
            </div>
            <div class="col-8 d-none d-md-block">
                <ul class="nav pis justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link" href="home">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="shop?all">فروشگاه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Site-Footer">درباره ما</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">مقالات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Site-Footer">تماس با ما</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-2 col-6">
                    <span class="btn mobile-menu-open d-md-none m-auto float-left">
                        <i class="fa fa-bars"></i>
                    </span>
            </div>
        </div>
    </div>

</header>
<div class="mobile-menu">
        <span class="mobile-menu-close">
            <i class="fa fa-times"></i>
        </span>
    <ul class="menu">
        <li class="menu-item">
            <a href="home">خانه</a>
        </li>
        <li class="menu-item">
            <a href="shop?all">فروشگاه</a>
        </li>
        <li class="menu-item">
            <a href="#Site-Footer">درباره ما</a>
        </li>
        <li class="menu-item">
            <a href="#">مقالات</a>
        </li>
        <li class="menu-item">
            <a href="#Site-Footer">تماس با ما</a>
        </li>
    </ul>
</div>

<main>
    <div id="Site-Wrapper" class="container-xl">
        <section class="single-product-preview">
            <div class="single-product-preview-inner row no-gutters">
                <div class="col-sm-6 pl-md-3 pl-sm-2 pl-0 mb-3 mb-sm-0">
                    <div class="row no-gutters">
                        <div class="product-image-wrap p-lg-5 p-md-3 p-sm-2 p-2 shadow-lg w-100">
                            <div class="product-image-container">
                                <div class="product-image-item">
                                    <div class="product-image-wrapper ">
                                        <img id="product-image" src="<?php echo $product->image[0]->image ?>" data-zoom-image="<?php echo $product->image[0]->image ?>" class="img-fluid" />
                                    </div>
                                </div>
                                <div class="swiper-container product-swiper-container">
                                    <div id="product-gallery" class="swiper-wrapper">
                                        <?php
                                        if (!empty($product->image)) {
                                            foreach ($product->image as $value) {
                                                ?>
                                                <a href="#" data-image="<?php echo $value->image ?>" data-zoom-image="<?php echo $value->image ?>" class="swiper-slide">
                                                    <img src="<?php echo $value->image ?>" class="img-fluid">
                                                </a>
                                            <?php }
                                        } ?>
                                    </div>
                                    <div class="product-slider-button-next swiper-button-next"></div>
                                    <div class="product-slider-button-prev swiper-button-prev"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 pr-md-3 pr-sm-2 pr-0">
                    <div class="row no-gutters h-100">
                        <div class="product-sale-details p-lg-5 p-md-3 p-sm-2 p-4 shadow-lg w-100">
                            <div class="product-sale-container">
                                <p class="small"><span class="font-weight-bold">دسته بندی: </span><?php echo $product->category ?>
                                </p>
                                <h1 class="product-title"> <?php echo $product->name ?></h1>
                                <span><?php echo $product->model ?></span>
                                <p class="mb-0"><span>وزن: </span><?php echo $product->weight ?> گرم</p>
                                <p class="product-price">
                                        <span class="price-amount">
                                            <bdi><?php echo number_format($product->price) ?><span class="price-symbol">&nbsp;ریال</span>
                                            </bdi>
                                        </span>
                                </p>
                                <?php
                                if (!empty($_COOKIE['id'])) {
                                    if ($product->count == 0) { ?>
                                        <div class="add-to-cart-container text-center">
                                            <button class="btn btn-lg btn-block btn-secondary" data-toggle="modal" data-target="#productfinished">اطلاع رسانی اتمام محصول <i class="fa fa-info"></i></button>
                                        </div>
                                        <!-- Modal: Product Finished Start -->
                                        <div class="modal fade" id="productfinished" tabindex="-1" aria-labelledby="productfinishedLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">اطلاع رسانی اتمام محصول</h5>
                                                    </div>
                                                    <div class="modal-body mb-1">
                                                        <form method="post">
                                                            <div class="form-group has-float-label">
                                                                <textarea placeholder="&nbsp;" name="message" id="info-message" class="form-control border-0" rows="5" required></textarea>
                                                                <span class="form-bar"></span>
                                                                <label class="float-label" for="info-message">پیام اطلاع رسانی</label>
                                                            </div>
                                                            <div class="text-center mt-2">
                                                                <button class="btn btn-block cta-btn" name="sendInfo" type="submit">ارسال پیام
                                                                    <i class="fas fa-info ml-1"></i>
                                                                </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-outline-danger" data-dismiss="modal">بستن</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal: Product Finished End -->
                                    <?php } else { ?>
                                        <div class="add-to-cart-container text-center">
                                            <form method="post">
                                                <button type="submit" name="add" class="btn btn-lg btn-block add-to-cart">افزودن به سبد خرید <i class="fa fa-shopping-cart"></i></button>
                                            </form>
                                        </div>
                                    <?php }
                                } else { ?>
                                    <div class="add-to-cart-container text-center">
                                        <button type="submit" name="add" class="btn btn-lg btn-block add-to-cart" data-toggle="modal" data-target="#modalLRForm">ابتدا وارد حساب کاربری خود شوید <i class="fa fa-user"></i></button>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="single-product-details py-3 py-md-4">
            <div class="product-details-wrapper m-auto">
                <ul class="nav pis py-2" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link nohover active" id="product-details-description-tab" data-toggle="pill" href="#product-details-description" role="tab" aria-controls="product-details-description" aria-selected="true">جزئیات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nohover" id="product-description-tab" data-toggle="pill" href="#product-description" role="tab" aria-controls="product-description" aria-selected="false">توضیحات تکمیلی</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nohover" id="product-comments-tab" data-toggle="pill" href="#product-comments" role="tab" aria-controls="product-comments" aria-selected="false">نظرات</a>
                    </li>
                </ul>
                <div class="tab-content" id="tabContent">
                    <div class="tab-pane fade show active" id="product-details-description" role="tabpanel" aria-labelledby="product-details-description-tab">
                        <table class="table table-borderless">
                            <tbody>
                            <tr>
                                <td>وزن</td>
                                <td><?php echo $product->weight ?> گرم</td>
                            </tr>
                            <tr>
                                <td>جنسیت</td>
                                <td><?php
                                    if ($product->gender == "men") {
                                        echo "مردانه";
                                    } elseif ($product->gender == "women") {
                                        echo "زنانه";
                                    } elseif ($product->gender == "both") {
                                        echo "هردو";
                                    }
                                    ?></td>
                            </tr>
                            <tr>
                                <td>عیار</td>
                                <td> عیار<?php echo $product->gold_carat ?></td>
                            </tr>
                            <tr>
                                <td>کالکشن</td>
                                <td><?php echo $product->colaction ?></td>
                            </tr>
                            <tr>
                                <td>رنگ</td>
                                <td><?php echo $product->color ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="product-description" role="tabpanel" aria-labelledby="product-description-tab">
                        <div class="decription-text p-3">
                            <p><?php echo $product->description ?></p>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="product-comments" role="tabpanel" aria-labelledby="product-comments-tab">
                        <div class="container-fluid p-3">
                            <div class="row no-gutters">
                                <?php
                                if (!empty($product->comment)) {
                                    foreach ($product->comment as $value) {
                                        ?>
                                        <div class="col-12">
                                            <div class="d-sm-flex mb-4">
                                                <img class="d-flex comment-avatar rounded-circle mt-sm-3 mb-sm-0 mb-3 ml-2 h-25" style="width: 5%" src="http://mondas.ir/site/retail/assets/images/man.svg">
                                                <div class="comment-body w-100 shadows bg-light p-3 p-md-5">
                                                    <div class="mb-2">
                                                        <h5 class="mb-0"><?php echo $value->user_name ?></h5>
                                                    </div>
                                                    <p><?php echo $value->comment ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                }  if(isset($_COOKIE['id'])){
                                ?>

                                    <div class="col-12">
                                        <div class="send-comment-wrapper bg-white rounded py-3 px-3 px-sm-4">
                                            <form method="post">
                                                <div class="form-group has-float-label mt-0">
                                                    <textarea placeholder="&nbsp;" name="comment" id="comment-message" class="form-control border-0 p-3" rows="5" required></textarea>
                                                    <span class="form-bar"></span>
                                                    <label class="float-label p-2" for="comment-message">دیدگاه شما</label>
                                                </div>
                                                <div class="mt-2">
                                                    <button class="btn cta-btn" name="sendComment" type="submit">ارسال
                                                        <i class="fas fa-comment-dots ml-1"></i>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>

                                <?php } ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="single-product-similar row ">
            <div class="col-12">
                <h2 class="position-relative w-100 text-center mb-4">محصولات مشابه</h2>
                <div class="product-similar-slider swiper-container py-5 px-4">
                    <div class="swiper-wrapper">
                        <?php
                        if (!empty($random)) {
                            foreach ($random as $item) {
                                ?>
                                <div class="swiper-slide">
                                    <a href="commodity?id=<?php echo $item->id ?>" class="card border-0 text-dark float-top nohover">
                                        <div class="card-img-top">
                                            <img class="img-fluid" src="<?php echo $item->ProductImages[0]->image ?>">
                                        </div>
                                        <div class="card-body">
                                            <ul class="pis list-inline">
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">مدل:
                                                        </span><?php echo $item->model ?>
                                                </li>
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">وزن:
                                                        </span><?php echo $item->weight ?>
                                                </li>
                                                <li class="mb-2">
                                                        <span class="font-weight-bold">قیمت:
                                                        </span><?php echo number_format($item->price) ?>
                                                    <span class="price-symbol">ریال</span>
                                                </li>
                                            </ul>
                                            <button class="btn rounded-pill cta-btn-primary d-block m-auto px-5">بیشتر
                                            </button>
                                        </div>
                                    </a>
                                </div>
                            <?php }
                        } ?>
                    </div>
                    <div class="product-similar-slider-button-next swiper-button-next"></div>
                    <div class="product-similar-slider-button-prev swiper-button-prev"></div>
                </div>
            </div>
        </section>
    </div>
</main>

<footer id="Site-Footer">
    <div class="footer-top container-xl py-3 py-lg-5">
        <div class="row">
            <div class="footer-column-1 col-sm-6 col-lg-3">
                <ul class="footer-menu list-inline pis text-center text-lg-right">
                    <li class="mb-3">
                        <a href="shop?all" class="p-2 text-dark">محصولات</a>
                    </li>
                    <li class="mb-3">
                        <a href="#" class="p-2 text-dark">مقالات</a>
                    </li>
                </ul>
            </div>
            <div class="footer-column-2 col-lg-6">
                <div class="logo text-center mb-4">
                    <a href="#"><img src="http://mondas.ir/site/retail/assets/images/logo.png"></a>
                </div>
                <h4 class="w-100 text-center">خبرنامه</h4>
                <p class="text-center">با وارد کردن ایمیل از جدید ترین محصولات ما با خبر شوید</p>
                <div class="container-fluid subscribe-news py-3">
                    <form class="form-inline mx-auto position-relative w-100" method="post">
                        <input type="email" class="form-control w-100" name="email" placeholder="ایمیل خود را وارد کنید" required>
                        <button type="submit" name="add" class="btn position-absolute">عضویت</button>
                    </form>
                </div>
            </div>
            <div class="footer-column-3 col-sm-6 col-lg-3">
                <div class="namad-container d-flex justify-content-between flex-column">
                    <div class="namad">
                        <a href="#"><img src="http://mondas.ir/site/retail/assets/images/enamad-logo.png"></a>
                    </div>
                    <!-- <div class="namad">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 <a href="#"><img src="assets/images/resane-logo.png"></a>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            </div> -->
                </div>
                <div class="social-icons">
                    <ul class="pis d-flex justify-content-center">
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-instagram-square"></i>
                            </a>
                        </li>
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-telegram"></i>
                            </a>
                        </li>
                        <li class="p-3">
                            <a href="#">
                                <i class="fab fa-whatsapp-square"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom container-xl py-3">
        <div class="row">
            <div class="col-12">
                <div class="footer-contact m-auto text-center w-50">
                    <div class="address d-flex justify-content-center align-items-center w-100 mb-2">
                        <i class="fa fa-map-marker-alt ml-3 tm-color"></i>
                        <p class="mb-0"><?php echo $about->addres  ?></p>
                    </div>
                    <div class="phone d-flex justify-content-center align-items-center w-100">
                        <i class="fa fa-phone ml-3 tm-color"></i>
                        <ul class="pis mb-0 list-inline d-flex">
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone1  ?></a>
                            </li>
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone2  ?></a>
                            </li>
                            <li class="px-1 px-sm-4">
                                <a class="text-dark" href="#"><?php echo $about->phone3  ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<span id="jump-to-top" class="shadows jump-to-top-container tm-color">
        <i class="fa fa-chevron-up"></i>
    </span>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/js/swiper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.bundle.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/2.2.3/jquery.elevatezoom.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js'></script>
<script src="http://mondas.ir/site/retail/assets/js/scripts.js"></script>

<?php
if (isset($_GET['comment'])) {
    if ($_GET['comment'] == "true") {
        echo "<script>swal(' باتشکر!','نظر شما با موفقیت ثبت گردید', 'success');</script>";
    } elseif ($_GET['comment'] == "false") {
        echo "<script>swal('متاسفیم', 'نظر شما با موفقیت ثبت نشد', 'error');</script>";
    }
}

if (isset($_GET['know'])) {
    if ($_GET['know'] == "true") {
        echo "<script>swal(' باتشکر!','محصول به زودی در دسترس قرار خواهد گرفت', 'success');</script>";
    } elseif ($_GET['know'] == "false") {
        echo "<script>swal('متاسفیم', 'پیغام شما ثبت نگردید', 'error');</script>";
    }
}
?>



</body>

</html>